-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_wpforms_tasks_meta
-- Snapshot Table  : 1608867401_wpforms_tasks_meta
--
-- SQL    : SELECT * FROM wps9_wpforms_tasks_meta LIMIT 0,10000
-- Offset : 0
-- Rows   : 34
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_wpforms_tasks_meta`
--
DROP TABLE  IF EXISTS `1608867401_wpforms_tasks_meta`;
CREATE TABLE `1608867401_wpforms_tasks_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_wpforms_tasks_meta`
-- Number of rows: 34
--
INSERT INTO `1608867401_wpforms_tasks_meta` VALUES 
(1,'wpforms_process_entry_emails_meta_cleanup','Wzg2NDAwXQ==','2020-09-30 10:31:45'),
 (2,'wpforms_admin_notifications_update','W10=','2020-09-30 10:34:13'),
 (3,'wpforms_admin_notifications_update','W10=','2020-10-01 13:52:56'),
 (4,'wpforms_admin_notifications_update','W10=','2020-10-02 14:04:04'),
 (5,'wpforms_admin_notifications_update','W10=','2020-10-03 14:04:40'),
 (6,'wpforms_admin_notifications_update','W10=','2020-10-06 13:24:58'),
 (7,'wpforms_admin_notifications_update','W10=','2020-10-08 13:32:09'),
 (8,'wpforms_admin_notifications_update','W10=','2020-10-09 13:58:04'),
 (9,'wpforms_admin_notifications_update','W10=','2020-10-10 14:07:19'),
 (10,'wpforms_admin_notifications_update','W10=','2020-10-17 14:38:20'),
 (11,'wpforms_admin_notifications_update','W10=','2020-10-17 14:54:09'),
 (12,'wpforms_admin_notifications_update','W10=','2020-10-23 13:15:17'),
 (13,'wpforms_admin_notifications_update','W10=','2020-10-27 10:05:25'),
 (14,'wpforms_admin_notifications_update','W10=','2020-10-30 03:23:22'),
 (15,'wpforms_admin_notifications_update','W10=','2020-11-01 03:42:33'),
 (16,'wpforms_admin_notifications_update','W10=','2020-11-09 02:34:32'),
 (17,'wpforms_admin_notifications_update','W10=','2020-11-10 04:16:05'),
 (18,'wpforms_process_entry_emails_meta_cleanup','Wzg2NDAwXQ==','2020-11-16 06:13:33'),
 (19,'wpforms_admin_notifications_update','W10=','2020-11-17 04:14:35'),
 (20,'wpforms_admin_notifications_update','W10=','2020-11-19 10:01:15'),
 (21,'wpforms_admin_notifications_update','W10=','2020-11-21 10:38:55'),
 (22,'wpforms_admin_notifications_update','W10=','2020-11-24 02:39:27'),
 (23,'wpforms_admin_notifications_update','W10=','2020-12-05 08:28:14'),
 (24,'wpforms_admin_notifications_update','W10=','2020-12-07 04:21:14'),
 (25,'wpforms_admin_notifications_update','W10=','2020-12-08 09:55:12'),
 (26,'wpforms_admin_notifications_update','W10=','2020-12-09 14:44:03'),
 (27,'wpforms_admin_notifications_update','W10=','2020-12-09 14:44:04'),
 (28,'wpforms_admin_notifications_update','W10=','2020-12-10 14:44:47'),
 (29,'wpforms_admin_notifications_update','W10=','2020-12-12 00:09:35'),
 (30,'wpforms_admin_notifications_update','W10=','2020-12-16 11:15:00'),
 (31,'wpforms_admin_notifications_update','W10=','2020-12-18 07:56:06'),
 (32,'wpforms_admin_notifications_update','W10=','2020-12-22 07:57:21'),
 (33,'wpforms_admin_notifications_update','W10=','2020-12-23 08:44:44'),
 (34,'wpforms_admin_notifications_update','W10=','2020-12-24 08:55:49');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
