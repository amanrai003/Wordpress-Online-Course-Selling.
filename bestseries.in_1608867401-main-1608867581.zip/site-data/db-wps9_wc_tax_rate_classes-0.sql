-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:38
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_wc_tax_rate_classes
-- Snapshot Table  : 1608867401_wc_tax_rate_classes
--
-- SQL    : SELECT * FROM wps9_wc_tax_rate_classes LIMIT 0,10000
-- Offset : 0
-- Rows   : 2
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_wc_tax_rate_classes`
--
DROP TABLE  IF EXISTS `1608867401_wc_tax_rate_classes`;
CREATE TABLE `1608867401_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_class_id`),
  UNIQUE KEY `slug` (`slug`(191))
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_wc_tax_rate_classes`
-- Number of rows: 2
--
INSERT INTO `1608867401_wc_tax_rate_classes` VALUES 
(1,'Reduced rate','reduced-rate'),
 (2,'Zero rate','zero-rate');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
