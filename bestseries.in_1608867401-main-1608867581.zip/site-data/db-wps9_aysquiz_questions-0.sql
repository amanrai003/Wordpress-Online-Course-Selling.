-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_aysquiz_questions
-- Snapshot Table  : 1608867401_aysquiz_questions
--
-- SQL    : SELECT * FROM wps9_aysquiz_questions LIMIT 0,10000
-- Offset : 0
-- Rows   : 25
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_aysquiz_questions`
--
DROP TABLE  IF EXISTS `1608867401_aysquiz_questions`;
CREATE TABLE `1608867401_aysquiz_questions` (
  `id` int(16) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(16) unsigned NOT NULL,
  `question` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `question_image` text COLLATE utf8mb4_unicode_520_ci,
  `wrong_answer_text` text COLLATE utf8mb4_unicode_520_ci,
  `right_answer_text` text COLLATE utf8mb4_unicode_520_ci,
  `question_hint` text COLLATE utf8mb4_unicode_520_ci,
  `explanation` text COLLATE utf8mb4_unicode_520_ci,
  `type` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `published` tinyint(3) unsigned NOT NULL,
  `create_date` datetime DEFAULT NULL,
  `not_influence_to_score` text COLLATE utf8mb4_unicode_520_ci,
  `weight` double DEFAULT '1',
  `options` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_aysquiz_questions`
-- Number of rows: 25
--
INSERT INTO `1608867401_aysquiz_questions` VALUES 
(7,2,'<p><strong>........... is the first woman to head a public sector bank.</strong></p>\n',NULL,'','','','','radio',1,'2020-09-06 02:20:10','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (8,2,'<p><strong> Where is Bose Institute ?</strong></p>\n',NULL,'','','','','radio',1,'2020-09-06 02:24:44','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (9,2,'<p><strong>When is the International Yoga Day celebrated ?</strong></p>\n',NULL,'','','','','radio',1,'2020-09-06 02:26:00','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (10,2,'<p><strong>\\\'SHIKHAR SE PUKAR\\\' is a documentary film related to which topic?</strong></p>\n',NULL,'','','','','radio',1,'2020-09-06 02:27:33','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (11,1,'<p><strong>World Tourism Day is celebrated on-</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:17:37','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (12,1,'<p><strong>The two-day festival \\\'North East Calling\\\', is organized by which ministry ?</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:18:52','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (13,1,'<p><strong>When Government of India confers the \\\"Highest Civilian Honor for Women\\\" by presenting \\\"Nari Shakti Puraskars\\\" ?</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:20:17','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (14,1,'<p><strong> Election Commission of India has decided that the voter\\\'s identification shall be mandatory in the elections at the time of poll. Which of the following shall be the main document of identification of a voter ?</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:21:18','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (15,1,'<p><strong>\\\'Line of Blood\\\' is a book written by whom?</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:22:46','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (16,1,'<p><strong> The order of the tricolour of the Indian Flag from top to bottom is in which of the following sequences?</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:23:32','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (17,1,'<p><strong>The Insurance Regulatory and Development Authority (IRDA) is a -</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:24:40','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (18,1,'<p><strong>A major in-stream use of water is for -</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:25:34','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (19,1,'<p><strong>Which of the following pairs is/ are correctly matched ?</strong><br />\n1. Francis Collins : Mapping human genome<br />\n2. Sergey Brin : Google Search Engine<br />\n3. Jimmy Wales : Wikipedia</p>\n',NULL,'','','','','radio',1,'2020-09-12 12:26:34','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (20,1,'<p><strong>Who among the following Scientists got two Nobel prizes of which one was in Peace?</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:28:13','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (21,1,'<p><strong>The first Indian State to go wholley organic is -</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:29:09','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (22,1,'<p><strong> Which among the following cities in India, is not located in Golden Quadrilateral Road Network?</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:30:11','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (23,1,'<p><strong>Which one of the following states of India has made unique venture of putting daughter’s nameplate on the front of the house?</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:46:16','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (24,1,'<p><strong>What is the name of Indira Gandhi\\\'s Samadhi?</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:47:33','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (25,1,'<p><strong>According to Census 2011, the district of Madhya Pradesh with highest female-male ratio is -</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:48:41','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (26,1,'<p><strong> What is the approximate present irrigation potential, in lakh hectares, of Madhya Pradesh?</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:49:41','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (27,1,'<p><strong> Madhya Pradesh State was constituted on -</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:52:26','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (28,1,'<p><strong> Who introduced \\\'Green Army\\\' for environment conservation?</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:53:18','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (29,1,'<p><strong>According to the World Health Organization the most affected country by Ebola was -</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:54:11','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (30,1,'<p><strong>Prime Minister Narendra Modi launched \\\'Swachha Bharat Mission\\\' officially on -</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:55:01','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}'),
 (31,1,'<p><strong>\\\'Kyoto Protocol\\\' is related to -</strong></p>\n',NULL,'','','','','radio',1,'2020-09-12 12:55:53','off',1,'{\"author\":\"{\\\"id\\\":1,\\\"name\\\":\\\"bestseries\\\"}\",\"use_html\":\"off\"}');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
