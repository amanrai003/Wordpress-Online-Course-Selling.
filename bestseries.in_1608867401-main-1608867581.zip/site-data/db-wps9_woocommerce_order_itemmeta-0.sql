-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_woocommerce_order_itemmeta
-- Snapshot Table  : 1608867401_woocommerce_order_itemmeta
--
-- SQL    : SELECT * FROM wps9_woocommerce_order_itemmeta LIMIT 0,10000
-- Offset : 0
-- Rows   : 129
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_woocommerce_order_itemmeta`
--
DROP TABLE  IF EXISTS `1608867401_woocommerce_order_itemmeta`;
CREATE TABLE `1608867401_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=MyISAM AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_woocommerce_order_itemmeta`
-- Number of rows: 129
--
INSERT INTO `1608867401_woocommerce_order_itemmeta` VALUES 
(1,1,'_product_id','1867'),
 (2,1,'_variation_id','0'),
 (3,1,'_qty','1'),
 (4,1,'_tax_class',''),
 (5,1,'_line_subtotal','100'),
 (6,1,'_line_subtotal_tax','0'),
 (7,1,'_line_total','100'),
 (8,1,'_line_tax','0'),
 (9,1,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
 (10,2,'_product_id','1869'),
 (11,2,'_variation_id','0'),
 (12,2,'_qty','1'),
 (13,2,'_tax_class',''),
 (14,2,'_line_subtotal','100'),
 (15,2,'_line_subtotal_tax','0'),
 (16,2,'_line_total','100'),
 (17,2,'_line_tax','0'),
 (18,2,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
 (19,3,'_product_id','1897'),
 (20,3,'_variation_id','0'),
 (21,3,'_qty','1'),
 (22,3,'_tax_class',''),
 (23,3,'_line_subtotal','100'),
 (24,3,'_line_subtotal_tax','0'),
 (25,3,'_line_total','100'),
 (26,3,'_line_tax','0'),
 (27,3,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
 (28,4,'_product_id','1889'),
 (29,4,'_variation_id','0'),
 (30,4,'_qty','1'),
 (31,4,'_tax_class',''),
 (32,4,'_line_subtotal','100'),
 (33,4,'_line_subtotal_tax','0'),
 (34,4,'_line_total','100'),
 (35,4,'_line_tax','0'),
 (36,4,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
 (37,5,'_product_id','1889'),
 (38,5,'_variation_id','0'),
 (39,5,'_qty','2'),
 (40,5,'_tax_class',''),
 (41,5,'_line_subtotal','4'),
 (42,5,'_line_subtotal_tax','0'),
 (43,5,'_line_total','4'),
 (44,5,'_line_tax','0'),
 (45,5,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
 (46,6,'_product_id','1889'),
 (47,6,'_variation_id','0'),
 (48,6,'_qty','1'),
 (49,6,'_tax_class',''),
 (50,6,'_line_subtotal','2'),
 (51,6,'_line_subtotal_tax','0'),
 (52,6,'_line_total','2'),
 (53,6,'_line_tax','0'),
 (54,6,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
 (55,7,'_product_id','1889'),
 (56,7,'_variation_id','0'),
 (57,7,'_qty','1'),
 (58,7,'_tax_class',''),
 (59,7,'_line_subtotal','2'),
 (60,7,'_line_subtotal_tax','0'),
 (61,7,'_line_total','2'),
 (62,7,'_line_tax','0'),
 (63,7,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
 (64,8,'_product_id','1889'),
 (65,8,'_variation_id','0'),
 (66,8,'_qty','1'),
 (67,8,'_tax_class',''),
 (68,8,'_line_subtotal','2'),
 (69,8,'_line_subtotal_tax','0'),
 (70,8,'_line_total','2'),
 (71,8,'_line_tax','0'),
 (72,8,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
 (73,9,'_product_id','1889'),
 (74,9,'_variation_id','0'),
 (75,9,'_qty','1'),
 (76,9,'_tax_class',''),
 (77,9,'_line_subtotal','2'),
 (78,9,'_line_subtotal_tax','0'),
 (79,9,'_line_total','2'),
 (80,9,'_line_tax','0'),
 (81,9,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
 (82,10,'_product_id','1889'),
 (83,10,'_variation_id','0'),
 (84,10,'_qty','1'),
 (85,10,'_tax_class',''),
 (86,10,'_line_subtotal','2'),
 (87,10,'_line_subtotal_tax','0'),
 (88,10,'_line_total','2'),
 (89,10,'_line_tax','0'),
 (90,10,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
 (91,11,'_product_id','1889'),
 (92,11,'_variation_id','0'),
 (93,11,'_qty','1'),
 (94,11,'_tax_class',''),
 (95,11,'_line_subtotal','2'),
 (96,11,'_line_subtotal_tax','0'),
 (97,11,'_line_total','2'),
 (98,11,'_line_tax','0'),
 (99,11,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
 (100,12,'_product_id','1889'),
 (101,12,'_variation_id','0'),
 (102,12,'_qty','2'),
 (103,12,'_tax_class',''),
 (104,12,'_line_subtotal','4'),
 (105,12,'_line_subtotal_tax','0'),
 (106,12,'_line_total','4'),
 (107,12,'_line_tax','0'),
 (108,12,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
 (109,13,'_product_id','1867'),
 (110,13,'_variation_id','0'),
 (111,13,'_qty','1'),
 (112,13,'_tax_class',''),
 (113,13,'_line_subtotal','159'),
 (114,13,'_line_subtotal_tax','0'),
 (115,13,'_line_total','159'),
 (116,13,'_line_tax','0'),
 (117,13,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
 (118,14,'_product_id','1883'),
 (119,14,'_variation_id','0'),
 (120,14,'_qty','2'),
 (121,14,'_tax_class',''),
 (122,14,'_line_subtotal','338'),
 (123,14,'_line_subtotal_tax','0'),
 (124,14,'_line_total','236.6'),
 (125,14,'_line_tax','0'),
 (126,14,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
 (127,15,'discount_amount','101.4'),
 (128,15,'discount_amount_tax','0'),
 (129,15,'coupon_data','a:24:{s:2:\"id\";i:3325;s:4:\"code\";s:9:\"special30\";s:6:\"amount\";s:2:\"30\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2020-12-12 06:57:32.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2020-12-12 06:57:32.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";N;s:13:\"discount_type\";s:7:\"percent\";s:11:\"description\";s:0:\"\";s:11:\"usage_count\";i:0;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
