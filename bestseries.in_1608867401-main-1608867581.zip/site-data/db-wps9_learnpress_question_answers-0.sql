-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_learnpress_question_answers
-- Snapshot Table  : 1608867401_learnpress_question_answers
--
-- SQL    : SELECT * FROM wps9_learnpress_question_answers LIMIT 0,10000
-- Offset : 0
-- Rows   : 67
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_learnpress_question_answers`
--
DROP TABLE  IF EXISTS `1608867401_learnpress_question_answers`;
CREATE TABLE `1608867401_learnpress_question_answers` (
  `question_answer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `question_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `answer_data` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `answer_order` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`question_answer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_learnpress_question_answers`
-- Number of rows: 67
--
INSERT INTO `1608867401_learnpress_question_answers` VALUES 
(1,39,'a:3:{s:4:\"text\";s:4:\"True\";s:5:\"value\";s:4:\"true\";s:7:\"is_true\";s:3:\"yes\";}',1),
 (2,39,'a:3:{s:4:\"text\";s:5:\"False\";s:5:\"value\";s:5:\"false\";s:7:\"is_true\";s:0:\"\";}',2),
 (3,40,'a:3:{s:4:\"text\";s:7:\"scaler \";s:5:\"value\";s:27:\"159898372214655f4e8e2a23c17\";s:7:\"is_true\";s:3:\"yes\";}',1),
 (4,40,'a:3:{s:4:\"text\";s:6:\"vector\";s:5:\"value\";s:27:\"159898372214655f4e8e2a23c1e\";s:7:\"is_true\";s:0:\"\";}',2),
 (5,40,'a:3:{s:4:\"text\";s:13:\"none of these\";s:5:\"value\";s:27:\"159898372214655f4e8e2a23c21\";s:7:\"is_true\";s:0:\"\";}',3),
 (6,42,'a:3:{s:4:\"text\";s:6:\"scaler\";s:5:\"value\";s:26:\"15989840843345f4e8f94518c0\";s:7:\"is_true\";s:0:\"\";}',1),
 (7,42,'a:3:{s:4:\"text\";s:6:\"vector\";s:5:\"value\";s:26:\"15989840843345f4e8f94518c5\";s:7:\"is_true\";s:3:\"yes\";}',2),
 (9,43,'a:3:{s:4:\"text\";s:11:\" Rutherford\";s:5:\"value\";s:27:\"159898420901035f4e901102843\";s:7:\"is_true\";s:0:\"\";}',1),
 (13,45,'a:3:{s:4:\"text\";s:16:\"Hydrogen nucleus\";s:5:\"value\";s:26:\"15989844489285f4e9100e291e\";s:7:\"is_true\";s:0:\"\";}',1),
 (10,43,'a:3:{s:4:\"text\";s:8:\"Chadwick\";s:5:\"value\";s:27:\"159898420901035f4e901102849\";s:7:\"is_true\";s:0:\"\";}',2),
 (11,43,'a:3:{s:4:\"text\";s:7:\"Thomson\";s:5:\"value\";s:27:\"159898420901035f4e90110284b\";s:7:\"is_true\";s:3:\"yes\";}',3),
 (12,43,'a:3:{s:4:\"text\";s:9:\"Goldstein\";s:5:\"value\";s:27:\"159898437166425f4e90b3a2274\";s:7:\"is_true\";s:0:\"\";}',4),
 (14,45,'a:3:{s:4:\"text\";s:13:\"Argon nucleus\";s:5:\"value\";s:26:\"15989844489285f4e9100e2924\";s:7:\"is_true\";s:0:\"\";}',2),
 (15,45,'a:3:{s:4:\"text\";s:14:\"Helium nucleus\";s:5:\"value\";s:26:\"15989844489285f4e9100e2926\";s:7:\"is_true\";s:3:\"yes\";}',3),
 (16,45,'a:3:{s:4:\"text\";s:13:\"None of these\";s:5:\"value\";s:27:\"159898449539245f4e912f5fce4\";s:7:\"is_true\";s:0:\"\";}',4),
 (17,46,'a:3:{s:4:\"text\";s:11:\"Decreases  \";s:5:\"value\";s:27:\"159898466849785f4e91dc7986d\";s:7:\"is_true\";s:3:\"yes\";}',1),
 (18,46,'a:3:{s:4:\"text\";s:9:\"Increases\";s:5:\"value\";s:27:\"159898466849785f4e91dc79872\";s:7:\"is_true\";s:0:\"\";}',2),
 (19,46,'a:3:{s:4:\"text\";s:35:\"First increases and then decreases \";s:5:\"value\";s:27:\"159898466849785f4e91dc79875\";s:7:\"is_true\";s:0:\"\";}',3),
 (20,46,'a:3:{s:4:\"text\";s:16:\"Remains constant\";s:5:\"value\";s:26:\"15989847238535f4e9213d03dc\";s:7:\"is_true\";b:0;}',4),
 (21,51,'a:3:{s:4:\"text\";s:13:\" Blue vitriol\";s:5:\"value\";s:27:\"159898510035415f4e938c5674c\";s:7:\"is_true\";s:0:\"\";}',1),
 (22,51,'a:3:{s:4:\"text\";s:11:\"Baking soda\";s:5:\"value\";s:27:\"159898510035415f4e938c56752\";s:7:\"is_true\";s:3:\"yes\";}',2),
 (23,51,'a:3:{s:4:\"text\";s:0:\"\";s:5:\"value\";s:27:\"159898510035415f4e938c56754\";s:7:\"is_true\";s:0:\"\";}',3),
 (24,52,'a:3:{s:4:\"text\";s:39:\"Water < Acetic acid < Hydrochloric acid\";s:5:\"value\";s:27:\"159898518657055f4e93e28b47f\";s:7:\"is_true\";s:3:\"yes\";}',1),
 (25,52,'a:3:{s:4:\"text\";s:39:\"Water < Hydrochloric acid < Acetic acid\";s:5:\"value\";s:27:\"159898518657055f4e93e28b48d\";s:7:\"is_true\";s:0:\"\";}',2),
 (26,52,'a:3:{s:4:\"text\";s:40:\" Hydrochloric acid < Water < Acetic acid\";s:5:\"value\";s:27:\"159898518657055f4e93e28b491\";s:7:\"is_true\";s:0:\"\";}',3),
 (27,53,'a:3:{s:4:\"text\";s:26:\" Zinc hydroxide and sodium\";s:5:\"value\";s:27:\"159898526078335f4e942cbf3b3\";s:7:\"is_true\";s:0:\"\";}',1),
 (28,53,'a:3:{s:4:\"text\";s:31:\"Sodium zincate and hydrogen gas\";s:5:\"value\";s:27:\"159898526078335f4e942cbf3ba\";s:7:\"is_true\";s:3:\"yes\";}',2),
 (29,53,'a:3:{s:4:\"text\";s:34:\"Sodium zinc-oxide and hydrogen gas\";s:5:\"value\";s:27:\"159898526078335f4e942cbf3bc\";s:7:\"is_true\";s:0:\"\";}',3),
 (30,54,'a:3:{s:4:\"text\";s:1:\"0\";s:5:\"value\";s:27:\"159898536200045f4e94920017a\";s:7:\"is_true\";s:3:\"yes\";}',1),
 (31,54,'a:3:{s:4:\"text\";s:4:\"30°\";s:5:\"value\";s:27:\"159898536200045f4e949200182\";s:7:\"is_true\";s:0:\"\";}',2),
 (32,54,'a:3:{s:4:\"text\";s:4:\"45°\";s:5:\"value\";s:27:\"159898536200045f4e949200184\";s:7:\"is_true\";s:0:\"\";}',3),
 (33,55,'a:3:{s:4:\"text\";s:26:\" to promote cell division.\";s:5:\"value\";s:27:\"159898545345565f4e94ed6f3a8\";s:7:\"is_true\";s:3:\"yes\";}',1),
 (34,55,'a:3:{s:4:\"text\";s:19:\" to inhibit growth.\";s:5:\"value\";s:27:\"159898545345565f4e94ed6f3ad\";s:7:\"is_true\";s:0:\"\";}',2),
 (35,55,'a:3:{s:4:\"text\";s:26:\"to promote growth of stem.\";s:5:\"value\";s:27:\"159898545345565f4e94ed6f3b0\";s:7:\"is_true\";s:0:\"\";}',3),
 (36,58,'a:3:{s:4:\"text\";s:7:\"Tetanus\";s:5:\"value\";s:27:\"159898611641645f4e978465a9c\";s:7:\"is_true\";s:3:\"yes\";}',1),
 (37,58,'a:3:{s:4:\"text\";s:8:\"Malaria \";s:5:\"value\";s:27:\"159898611641645f4e978465aa2\";s:7:\"is_true\";s:0:\"\";}',2),
 (38,58,'a:3:{s:4:\"text\";s:8:\"Ringworm\";s:5:\"value\";s:27:\"159898611641645f4e978465aa5\";s:7:\"is_true\";s:0:\"\";}',3),
 (39,59,'a:3:{s:4:\"text\";s:4:\"true\";s:5:\"value\";s:27:\"159898622788835f4e97f3d8e10\";s:7:\"is_true\";s:3:\"yes\";}',1),
 (40,59,'a:3:{s:4:\"text\";s:5:\"false\";s:5:\"value\";s:27:\"159898622788835f4e97f3d8e16\";s:7:\"is_true\";s:0:\"\";}',2),
 (42,60,'a:3:{s:4:\"text\";s:7:\"Viruses\";s:5:\"value\";s:27:\"159898628083815f4e9828cc9ff\";s:7:\"is_true\";s:0:\"\";}',1),
 (45,61,'a:3:{s:4:\"text\";s:5:\"fungi\";s:5:\"value\";s:27:\"159898641291485f4e98acdf544\";s:7:\"is_true\";s:0:\"\";}',1),
 (43,60,'a:3:{s:4:\"text\";s:9:\"bacteria \";s:5:\"value\";s:27:\"159898628083815f4e9828cca05\";s:7:\"is_true\";s:0:\"\";}',2),
 (44,60,'a:3:{s:4:\"text\";s:7:\"viruses\";s:5:\"value\";s:27:\"159898628083825f4e9828cca09\";s:7:\"is_true\";s:3:\"yes\";}',3),
 (46,61,'a:3:{s:4:\"text\";s:5:\"algae\";s:5:\"value\";s:27:\"159898641291485f4e98acdf54a\";s:7:\"is_true\";s:0:\"\";}',2),
 (47,61,'a:3:{s:4:\"text\";s:8:\"bacteria\";s:5:\"value\";s:27:\"159898641291485f4e98acdf54d\";s:7:\"is_true\";s:3:\"yes\";}',3),
 (48,62,'a:3:{s:4:\"text\";s:4:\"True\";s:5:\"value\";s:4:\"true\";s:7:\"is_true\";s:3:\"yes\";}',1),
 (49,62,'a:3:{s:4:\"text\";s:5:\"False\";s:5:\"value\";s:5:\"false\";s:7:\"is_true\";s:0:\"\";}',2),
 (50,68,'a:3:{s:4:\"text\";s:1:\"7\";s:5:\"value\";s:27:\"159898686452395f4e9a707fe89\";s:7:\"is_true\";s:0:\"\";}',1),
 (51,68,'a:3:{s:4:\"text\";s:1:\"4\";s:5:\"value\";s:27:\"159898686452395f4e9a707fe90\";s:7:\"is_true\";s:3:\"yes\";}',2),
 (52,68,'a:3:{s:4:\"text\";s:1:\"5\";s:5:\"value\";s:27:\"159898686452395f4e9a707fe92\";s:7:\"is_true\";s:0:\"\";}',3),
 (53,68,'a:3:{s:4:\"text\";s:1:\"8\";s:5:\"value\";s:27:\"159898690620755f4e9a9a32abd\";s:7:\"is_true\";s:0:\"\";}',4),
 (54,69,'a:3:{s:4:\"text\";s:2:\"3A\";s:5:\"value\";s:26:\"15989869666175f4e9ad696a27\";s:7:\"is_true\";s:0:\"\";}',1),
 (55,69,'a:3:{s:4:\"text\";s:2:\"5I\";s:5:\"value\";s:26:\"15989869666175f4e9ad696a2c\";s:7:\"is_true\";s:0:\"\";}',2),
 (56,69,'a:3:{s:4:\"text\";s:1:\"I\";s:5:\"value\";s:26:\"15989869666175f4e9ad696a2f\";s:7:\"is_true\";s:3:\"yes\";}',3),
 (57,69,'a:3:{s:4:\"text\";s:0:\"\";s:5:\"value\";s:26:\"15989870094925f4e9b01781ff\";s:7:\"is_true\";s:0:\"\";}',4),
 (58,70,'a:3:{s:4:\"text\";s:5:\"17/20\";s:5:\"value\";s:27:\"159898707311995f4e9b411d46a\";s:7:\"is_true\";s:3:\"yes\";}',1),
 (59,70,'a:3:{s:4:\"text\";s:5:\"14/17\";s:5:\"value\";s:27:\"159898707311995f4e9b411d470\";s:7:\"is_true\";s:0:\"\";}',2),
 (60,70,'a:3:{s:4:\"text\";s:5:\"17/14\";s:5:\"value\";s:27:\"159898707311995f4e9b411d473\";s:7:\"is_true\";s:0:\"\";}',3),
 (61,70,'a:3:{s:4:\"text\";s:13:\"none of these\";s:5:\"value\";s:27:\"159898710848225f4e9b6475bbb\";s:7:\"is_true\";b:0;}',4),
 (62,71,'a:3:{s:4:\"text\";s:5:\" K|A|\";s:5:\"value\";s:27:\"159898717836895f4e9baa5a10d\";s:7:\"is_true\";s:0:\"\";}',1),
 (63,71,'a:3:{s:4:\"text\";s:7:\" K²|A|\";s:5:\"value\";s:27:\"159898717836895f4e9baa5a113\";s:7:\"is_true\";s:3:\"yes\";}',2),
 (64,71,'a:3:{s:4:\"text\";s:5:\"2K|A|\";s:5:\"value\";s:27:\"159898717836895f4e9baa5a116\";s:7:\"is_true\";s:0:\"\";}',3),
 (65,71,'a:3:{s:4:\"text\";s:13:\"none of these\";s:5:\"value\";s:27:\"159898723861745f4e9be696bc5\";s:7:\"is_true\";b:0;}',4),
 (66,72,'a:3:{s:4:\"text\";s:1:\"2\";s:5:\"value\";s:27:\"159898728831885f4e9c184dd6e\";s:7:\"is_true\";s:0:\"\";}',1),
 (67,72,'a:3:{s:4:\"text\";s:1:\"0\";s:5:\"value\";s:27:\"159898728831885f4e9c184dd73\";s:7:\"is_true\";s:0:\"\";}',2),
 (68,72,'a:3:{s:4:\"text\";s:5:\"√43\";s:5:\"value\";s:27:\"159898728831885f4e9c184dd76\";s:7:\"is_true\";s:0:\"\";}',3),
 (69,72,'a:3:{s:4:\"text\";s:5:\"√74\";s:5:\"value\";s:27:\"159898732768615f4e9c3fa781a\";s:7:\"is_true\";s:3:\"yes\";}',4);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
