-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_woocommerce_order_items
-- Snapshot Table  : 1608867401_woocommerce_order_items
--
-- SQL    : SELECT * FROM wps9_woocommerce_order_items LIMIT 0,10000
-- Offset : 0
-- Rows   : 15
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_woocommerce_order_items`
--
DROP TABLE  IF EXISTS `1608867401_woocommerce_order_items`;
CREATE TABLE `1608867401_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_woocommerce_order_items`
-- Number of rows: 15
--
INSERT INTO `1608867401_woocommerce_order_items` VALUES 
(1,'10th Class Mathematics','line_item',2018),
 (2,'10th Class English','line_item',2020),
 (3,'12th Class PCB(All in one)','line_item',2031),
 (4,'10th Class(All in one)','line_item',2033),
 (5,'10th Class(All in one)','line_item',2035),
 (6,'10th Class(All in one)','line_item',2037),
 (7,'10th Class(All in one)','line_item',2039),
 (8,'10th Class(All in one)','line_item',2073),
 (9,'10th Class(All in one)','line_item',2075),
 (10,'10th Class(All in one)','line_item',2079),
 (11,'10th Class(All in one)','line_item',2081),
 (12,'10th Class(All in one)','line_item',2083),
 (13,'10th Class Mathematics','line_item',3329),
 (14,'12th Class Physics','line_item',3347),
 (15,'special30','coupon',3347);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
