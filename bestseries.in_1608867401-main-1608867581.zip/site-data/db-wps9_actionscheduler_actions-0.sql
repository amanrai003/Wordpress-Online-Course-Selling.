-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_actionscheduler_actions
-- Snapshot Table  : 1608867401_actionscheduler_actions
--
-- SQL    : SELECT * FROM wps9_actionscheduler_actions LIMIT 0,10000
-- Offset : 0
-- Rows   : 30
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_actionscheduler_actions`
--
DROP TABLE  IF EXISTS `1608867401_actionscheduler_actions`;
CREATE TABLE `1608867401_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `scheduled_date_local` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `args` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `last_attempt_local` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id` (`claim_id`)
) ENGINE=MyISAM AUTO_INCREMENT=257 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_actionscheduler_actions`
-- Number of rows: 30
--
INSERT INTO `1608867401_actionscheduler_actions` VALUES 
(234,'wpforms_admin_notifications_update','complete','1970-01-02 00:00:01','1970-01-02 00:00:01','{\"tasks_meta_id\":24}','O:28:\"ActionScheduler_NullSchedule\":0:{}',2,1,'2020-12-07 04:21:15','2020-12-07 04:21:15',0,NULL),
 (236,'action_scheduler/migration_hook','complete','2020-12-09 06:23:49','2020-12-09 06:23:49','[]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1607495029;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1607495029;}',1,1,'2020-12-09 06:23:49','2020-12-09 06:23:49',0,NULL),
 (240,'wpforms_admin_notifications_update','complete','1970-01-02 00:00:01','1970-01-02 00:00:01','{\"tasks_meta_id\":28}','O:28:\"ActionScheduler_NullSchedule\":0:{}',2,1,'2020-12-10 14:45:24','2020-12-10 14:45:24',0,NULL),
 (235,'wpforms_admin_notifications_update','complete','1970-01-02 00:00:01','1970-01-02 00:00:01','{\"tasks_meta_id\":25}','O:28:\"ActionScheduler_NullSchedule\":0:{}',2,1,'2020-12-08 09:55:13','2020-12-08 09:55:13',0,NULL),
 (237,'wpforms_admin_notifications_update','complete','1970-01-02 00:00:01','1970-01-02 00:00:01','{\"tasks_meta_id\":26}','O:28:\"ActionScheduler_NullSchedule\":0:{}',2,1,'2020-12-09 14:44:04','2020-12-09 14:44:04',0,NULL),
 (238,'wpforms_admin_notifications_update','complete','1970-01-02 00:00:01','1970-01-02 00:00:01','{\"tasks_meta_id\":27}','O:28:\"ActionScheduler_NullSchedule\":0:{}',2,1,'2020-12-09 14:44:10','2020-12-09 14:44:10',0,NULL),
 (239,'action_scheduler/migration_hook','complete','2020-12-09 18:15:05','2020-12-09 18:15:05','[]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1607537705;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1607537705;}',1,1,'2020-12-09 18:15:24','2020-12-09 18:15:24',0,NULL),
 (244,'wc-admin_import_orders','complete','2020-12-12 10:08:23','2020-12-12 10:08:23','[3329]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1607767703;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1607767703;}',3,1,'2020-12-13 09:04:54','2020-12-13 09:04:54',0,NULL),
 (242,'woocommerce_update_marketplace_suggestions','complete','2020-12-12 05:37:35','2020-12-12 05:37:35','[]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1607751455;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1607751455;}',0,1,'2020-12-12 05:37:51','2020-12-12 05:37:51',0,NULL),
 (243,'wc-admin_import_customers','complete','2020-12-12 10:08:23','2020-12-12 10:08:23','[3]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1607767703;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1607767703;}',3,1,'2020-12-13 09:04:54','2020-12-13 09:04:54',0,NULL),
 (245,'wpforms_admin_notifications_update','complete','1970-01-02 00:00:01','1970-01-02 00:00:01','{\"tasks_meta_id\":30}','O:28:\"ActionScheduler_NullSchedule\":0:{}',2,1,'2020-12-16 11:15:01','2020-12-16 11:15:01',0,NULL),
 (248,'wc-admin_import_customers','complete','2020-12-20 15:18:47','2020-12-20 15:18:47','[20]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1608477527;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1608477527;}',3,1,'2020-12-20 15:21:53','2020-12-20 15:21:53',0,NULL),
 (249,'wc-admin_import_orders','complete','2020-12-20 15:18:47','2020-12-20 15:18:47','[3347]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1608477527;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1608477527;}',3,1,'2020-12-20 15:21:53','2020-12-20 15:21:53',0,NULL),
 (251,'woocommerce_update_marketplace_suggestions','complete','2020-12-22 08:02:36','2020-12-22 08:02:36','[]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1608624156;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1608624156;}',0,1,'2020-12-22 08:03:18','2020-12-22 08:03:18',0,NULL),
 (252,'wc-admin_import_customers','complete','2020-12-22 08:03:04','2020-12-22 08:03:04','[20]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1608624184;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1608624184;}',3,1,'2020-12-22 08:03:18','2020-12-22 08:03:18',0,NULL),
 (253,'wc-admin_import_orders','complete','2020-12-22 08:03:04','2020-12-22 08:03:04','[3347]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1608624184;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1608624184;}',3,1,'2020-12-22 08:03:18','2020-12-22 08:03:18',0,NULL),
 (226,'wpforms_process_entry_emails_meta_cleanup','pending','2021-01-02 22:43:49','2021-01-02 22:43:49','{\"tasks_meta_id\":18}','O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1609627429;s:18:\"\0*\0first_timestamp\";i:1605571200;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1609627429;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',2,0,'1970-01-02 00:00:01','1970-01-02 00:00:01',0,NULL),
 (227,'wpforms_process_entry_emails_meta_cleanup','pending','2021-01-02 22:43:49','2021-01-02 22:43:49','{\"tasks_meta_id\":1}','O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1609627429;s:18:\"\0*\0first_timestamp\";i:1601510400;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1609627429;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',2,0,'1970-01-02 00:00:01','1970-01-02 00:00:01',0,NULL),
 (254,'wpforms_admin_notifications_update','complete','1970-01-02 00:00:01','1970-01-02 00:00:01','{\"tasks_meta_id\":33}','O:28:\"ActionScheduler_NullSchedule\":0:{}',2,1,'2020-12-23 08:45:37','2020-12-23 08:45:37',0,NULL),
 (221,'wpforms_process_entry_emails_meta_cleanup','complete','2020-11-18 03:06:53','2020-11-18 03:06:53','{\"tasks_meta_id\":18}','O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1605668813;s:18:\"\0*\0first_timestamp\";i:1605571200;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1605668813;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',2,1,'2021-01-01 22:43:49','2021-01-01 22:43:49',0,NULL),
 (250,'wpforms_admin_notifications_update','complete','1970-01-02 00:00:01','1970-01-02 00:00:01','{\"tasks_meta_id\":32}','O:28:\"ActionScheduler_NullSchedule\":0:{}',2,1,'2020-12-22 07:57:23','2020-12-22 07:57:23',0,NULL),
 (256,'wpforms_admin_notifications_update','complete','1970-01-02 00:00:01','1970-01-02 00:00:01','{\"tasks_meta_id\":34}','O:28:\"ActionScheduler_NullSchedule\":0:{}',2,1,'2020-12-24 08:55:51','2020-12-24 08:55:51',0,NULL),
 (255,'action_scheduler/migration_hook','complete','2020-12-23 09:03:56','2020-12-23 09:03:56','[]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1608714236;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1608714236;}',1,1,'2020-12-23 11:19:45','2020-12-23 11:19:45',0,NULL),
 (231,'wpforms_admin_notifications_update','complete','1970-01-02 00:00:01','1970-01-02 00:00:01','{\"tasks_meta_id\":22}','O:28:\"ActionScheduler_NullSchedule\":0:{}',2,1,'2020-11-24 02:39:30','2020-11-24 02:39:30',0,NULL),
 (232,'action_scheduler/migration_hook','complete','2020-11-24 03:26:02','2020-11-24 03:26:02','[]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1606188362;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1606188362;}',1,1,'2020-11-24 03:26:44','2020-11-24 03:26:44',0,NULL),
 (241,'wpforms_admin_notifications_update','complete','1970-01-02 00:00:01','1970-01-02 00:00:01','{\"tasks_meta_id\":29}','O:28:\"ActionScheduler_NullSchedule\":0:{}',2,1,'2020-12-12 00:09:36','2020-12-12 00:09:36',0,NULL),
 (246,'wc-admin_import_orders','complete','2020-12-16 11:16:53','2020-12-16 11:16:53','[3329]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1608117413;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1608117413;}',3,1,'2020-12-16 11:17:12','2020-12-16 11:17:12',0,NULL),
 (247,'wpforms_admin_notifications_update','complete','1970-01-02 00:00:01','1970-01-02 00:00:01','{\"tasks_meta_id\":31}','O:28:\"ActionScheduler_NullSchedule\":0:{}',2,1,'2020-12-18 07:56:07','2020-12-18 07:56:07',0,NULL),
 (225,'wpforms_process_entry_emails_meta_cleanup','complete','2020-11-18 07:30:55','2020-11-18 07:30:55','{\"tasks_meta_id\":1}','O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1605684655;s:18:\"\0*\0first_timestamp\";i:1601510400;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1605684655;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',2,1,'2021-01-01 22:43:49','2021-01-01 22:43:49',0,NULL),
 (233,'wpforms_admin_notifications_update','complete','1970-01-02 00:00:01','1970-01-02 00:00:01','{\"tasks_meta_id\":23}','O:28:\"ActionScheduler_NullSchedule\":0:{}',2,1,'2020-12-05 08:28:28','2020-12-05 08:28:28',0,NULL);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
