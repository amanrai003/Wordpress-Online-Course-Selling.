-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_wc_product_meta_lookup
-- Snapshot Table  : 1608867401_wc_product_meta_lookup
--
-- SQL    : SELECT * FROM wps9_wc_product_meta_lookup LIMIT 0,10000
-- Offset : 0
-- Rows   : 51
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_wc_product_meta_lookup`
--
DROP TABLE  IF EXISTS `1608867401_wc_product_meta_lookup`;
CREATE TABLE `1608867401_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT '0',
  `downloadable` tinyint(1) DEFAULT '0',
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT '0',
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT '0',
  `average_rating` decimal(3,2) DEFAULT '0.00',
  `total_sales` bigint(20) DEFAULT '0',
  `tax_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'taxable',
  `tax_class` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_wc_product_meta_lookup`
-- Number of rows: 51
--
INSERT INTO `1608867401_wc_product_meta_lookup` VALUES 
(1857,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1858,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1859,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1861,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1864,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1865,'',1,0,149.0000,149.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1866,'',1,0,149.0000,149.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1867,'',1,0,159.0000,159.0000,1,NULL,'instock',0,0.00,1,'taxable',''),
 (1868,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1869,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1870,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1871,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1872,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1873,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1874,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1875,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1876,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1877,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1878,'',1,0,149.0000,149.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1879,'',1,0,179.0000,179.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1880,'',1,0,159.0000,159.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1881,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1882,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1883,'',1,0,169.0000,169.0000,1,NULL,'instock',0,0.00,2,'taxable',''),
 (1884,'',1,0,159.0000,159.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1885,'',1,0,179.0000,179.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1886,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1889,'',1,0,399.0000,399.0000,1,NULL,'instock',0,0.00,3,'taxable',''),
 (1890,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1891,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1892,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1893,'',0,0,100.0000,100.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1894,'',1,0,149.0000,149.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1895,'',1,0,389.0000,389.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1896,'',1,0,399.0000,399.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (1897,'',1,0,389.0000,389.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (3386,'',1,0,389.0000,389.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (3388,'',1,0,599.0000,599.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (3389,'',1,0,599.0000,599.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (3390,'',1,0,599.0000,599.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (3391,'',1,0,229.0000,229.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (3392,'',1,0,259.0000,259.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (3394,'',1,0,239.0000,239.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (3395,'',1,0,249.0000,249.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (3396,'',1,0,239.0000,239.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (3397,'',1,0,259.0000,259.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (3398,'',1,0,229.0000,229.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (3412,'',1,0,579.0000,579.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (3413,'',1,0,239.0000,239.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (3414,'',1,0,229.0000,229.0000,1,NULL,'instock',0,0.00,0,'taxable',''),
 (3415,'',1,0,229.0000,229.0000,1,NULL,'instock',0,0.00,0,'taxable','');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
