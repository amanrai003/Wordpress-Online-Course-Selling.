-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_users
-- Snapshot Table  : 1608867401_users
--
-- SQL    : SELECT * FROM wps9_users LIMIT 0,10000
-- Offset : 0
-- Rows   : 22
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_users`
--
DROP TABLE  IF EXISTS `1608867401_users`;
CREATE TABLE `1608867401_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_users`
-- Number of rows: 22
--
INSERT INTO `1608867401_users` VALUES 
(1,'bestseries','$P$B0/72fZyhkVkluHyM/hYXrxijTi.U7.','bestseries','support@bestseries.in','https://bestseries.in','2020-09-01 06:30:08','',0,'bestseries'),
 (2,'meghansh','$P$B9B58IUgSTbFjTEDB8gUxPIUVdwUaB1','meghansh','meghanshsaxena1@gmail.com','','2020-10-03 15:33:42','',0,'Meghansh Saxena'),
 (3,'raj','$P$BKerVlABBYQTwtA5cxA6GKKvbX3x/q0','raj','rajsonaniya24@gmail.com','','2020-10-03 16:43:37','',0,'Raj Patel'),
 (4,'sandeep','$P$B517KR691nFydfqHa.VTt2.aZpN343/','sandeep','sandeepjadoun777@gmail.com','','2020-10-04 14:08:08','',0,'Sandeep Singh jadoun'),
 (5,'raj1','$P$Bb3JvsJWtNXwlAGw9UcMCyJjGEP5Lm1','raj1','arjun.100naniya@gmail.com','','2020-11-09 19:47:50','',0,'Raj Patel'),
 (6,'aman','$P$B/a2I1bZ7YxSbUKYl0tddbRDI/4dCK1','aman','amanraiy333@gmail.com','','2020-11-10 04:24:22','',0,'Aman Rai'),
 (7,'meghanshsaxena','$P$B5sa8DhwPW8nLvBEQn4Xs2V2fo1qsB/','meghanshsaxena','meghanshhsaxenaa@gmail.com','','2020-11-10 10:51:05','',0,'Meghansh Saxena'),
 (8,'tanu123','$P$BQu0WxlMe4Fo8VSql4JpOsOECIsHNS.','tanu123','Tanu96285@gmail.com','','2020-11-17 13:54:07','',0,'Tanu Singh'),
 (9,'sajid6688','$P$ByOchltU5shpPk6WlKLIGkVGNbBL71/','sajid6688','sajidkhan90069@gmail.com','','2020-11-20 15:03:57','',0,'Sajid Khan'),
 (10,'shiva','$P$BzfEUdXKU8AxnLGko3k2ssWeJp/SY7/','shiva','shivanshsaxena197@gmail.com','','2020-11-22 13:06:22','1607751754:$P$B9xeubT3JsIeujKqGxDqs8n369EM0A/',0,'Shivansh Saxena'),
 (11,'muskan_21','$P$BaoA5dMk2SM9OMBJsTKk/dwohHTC6X.','muskan_21','vmuskan805@gmail.com','','2020-11-26 16:46:17','',0,'Muskan Verma'),
 (12,'amits','$P$BpDVPKrGWCw/PdfmpHeHBMJJRGIPdw.','amits','amitsaxena1911@yahoo.com','','2020-12-09 18:07:56','',0,'Amit Saxena'),
 (13,'tinku','$P$BfE1BTd2lWynztkBj3zVMF5ulyWtS9.','tinku','tinku@gmail.com','','2020-12-10 05:12:54','',0,'tinku tinku'),
 (14,'nisit','$P$B9tbv/o5bCrzyny.rBC9hwRSI4IoY60','nisit','nisitsaxena@gmail.com','','2020-12-10 13:16:38','',0,'Nisit Saxena'),
 (15,'guru12','$P$BoJ9du7wMwqq8qFhUi8W4uShJB99tC0','guru12','gouravsonaniya66@gmail.com','','2020-12-11 04:40:55','',0,'Gourav Sonaniya'),
 (16,'sandeep11','$P$B4OKsBT77fgYD6F7mzN6OzMAfLC/eE/','sandeep11','sandeepjadaun777@gmail.com','','2020-12-11 10:40:35','',0,'Sandeep Jadoun'),
 (17,'arvind','$P$BP4C9NPhMmZJqnqPb6ukRqKy2RKjkg.','arvind','arvind191291@gmail.com','','2020-12-12 09:00:30','',0,'Arvind patel'),
 (18,'aryman19','$P$BNQR4hSIirEAJWMiSkaDdJDb0DZODg.','aryman19','aryman1900d@gmail.com','','2020-12-13 12:11:04','',0,'Aaryman Deshmukh'),
 (19,'akash','$P$Bh/UhfDKn3IS791bBdbX6tYcc/lk5T1','akash','akashakku8982@gmail.com','','2020-12-20 14:12:36','',0,'Akash Choudhary'),
 (20,'mahirajat','$P$Bb.jjX3d9ylkVFKDyXBUEnDRDR7CW..','mahirajat','Babita.100naniya@gmail.com','','2020-12-20 15:14:14','',0,'Mahi Patel'),
 (21,'rudra25','$P$BOOtODJNO3JdhunKlt/ZZ5feWz/j6..','rudra25','rudrakush25@gmail.com','','2020-12-21 09:19:13','',0,'Rudra Kushwah'),
 (22,'yashgupta','$P$B.VgsHQ3Qvjt4eCBXYFcKwGe6IVJ/A0','yashgupta','yashgupta9893983878@gmail.com','','2020-12-24 07:24:44','',0,'Yash Gupta');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
