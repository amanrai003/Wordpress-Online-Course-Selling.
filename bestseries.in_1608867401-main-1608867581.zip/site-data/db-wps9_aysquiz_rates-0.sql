-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:38
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_aysquiz_rates
-- Snapshot Table  : 1608867401_aysquiz_rates
--
-- SQL    : SELECT * FROM wps9_aysquiz_rates LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_aysquiz_rates`
--
DROP TABLE  IF EXISTS `1608867401_aysquiz_rates`;
CREATE TABLE `1608867401_aysquiz_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_ip` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_name` text COLLATE utf8mb4_unicode_520_ci,
  `user_email` text COLLATE utf8mb4_unicode_520_ci,
  `user_phone` text COLLATE utf8mb4_unicode_520_ci,
  `rate_date` datetime NOT NULL,
  `score` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `review` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `options` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_aysquiz_rates`
-- Number of rows: 0
--
--
-- Data for table `wps9_aysquiz_rates`
-- Number of rows: 0
--
SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
