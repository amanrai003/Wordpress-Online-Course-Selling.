-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_learnpress_section_items
-- Snapshot Table  : 1608867401_learnpress_section_items
--
-- SQL    : SELECT * FROM wps9_learnpress_section_items LIMIT 0,10000
-- Offset : 0
-- Rows   : 7
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_learnpress_section_items`
--
DROP TABLE  IF EXISTS `1608867401_learnpress_section_items`;
CREATE TABLE `1608867401_learnpress_section_items` (
  `section_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `section_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `item_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `item_order` bigint(20) unsigned NOT NULL DEFAULT '0',
  `item_type` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`section_item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_learnpress_section_items`
-- Number of rows: 7
--
INSERT INTO `1608867401_learnpress_section_items` VALUES 
(1,1,162,1,'lp_lesson'),
 (2,1,163,2,'lp_lesson'),
 (3,1,164,3,'lp_lesson'),
 (4,1,165,4,'lp_lesson'),
 (5,1,166,5,'lp_lesson'),
 (6,1,167,6,'lp_lesson'),
 (7,1,168,7,'lp_lesson');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
