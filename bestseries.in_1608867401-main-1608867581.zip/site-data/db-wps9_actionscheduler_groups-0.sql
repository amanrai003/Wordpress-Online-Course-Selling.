-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_actionscheduler_groups
-- Snapshot Table  : 1608867401_actionscheduler_groups
--
-- SQL    : SELECT * FROM wps9_actionscheduler_groups LIMIT 0,10000
-- Offset : 0
-- Rows   : 3
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_actionscheduler_groups`
--
DROP TABLE  IF EXISTS `1608867401_actionscheduler_groups`;
CREATE TABLE `1608867401_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_actionscheduler_groups`
-- Number of rows: 3
--
INSERT INTO `1608867401_actionscheduler_groups` VALUES 
(1,'action-scheduler-migration'),
 (2,'wpforms'),
 (3,'wc-admin-data');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
