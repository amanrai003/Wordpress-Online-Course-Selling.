-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:39
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_tutor_quiz_question_answers
-- Snapshot Table  : 1608867401_tutor_quiz_question_answers
--
-- SQL    : SELECT * FROM wps9_tutor_quiz_question_answers LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_tutor_quiz_question_answers`
--
DROP TABLE  IF EXISTS `1608867401_tutor_quiz_question_answers`;
CREATE TABLE `1608867401_tutor_quiz_question_answers` (
  `answer_id` int(11) NOT NULL AUTO_INCREMENT,
  `belongs_question_id` int(11) DEFAULT NULL,
  `belongs_question_type` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `answer_title` text COLLATE utf8mb4_unicode_520_ci,
  `is_correct` tinyint(4) DEFAULT NULL,
  `image_id` int(11) DEFAULT NULL,
  `answer_two_gap_match` text COLLATE utf8mb4_unicode_520_ci,
  `answer_view_format` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `answer_settings` text COLLATE utf8mb4_unicode_520_ci,
  `answer_order` int(11) DEFAULT '0',
  PRIMARY KEY (`answer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_tutor_quiz_question_answers`
-- Number of rows: 0
--
--
-- Data for table `wps9_tutor_quiz_question_answers`
-- Number of rows: 0
--
SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
