-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:38
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_aysquiz_quizes
-- Snapshot Table  : 1608867401_aysquiz_quizes
--
-- SQL    : SELECT * FROM wps9_aysquiz_quizes LIMIT 0,10000
-- Offset : 0
-- Rows   : 1
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_aysquiz_quizes`
--
DROP TABLE  IF EXISTS `1608867401_aysquiz_quizes`;
CREATE TABLE `1608867401_aysquiz_quizes` (
  `id` int(16) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `quiz_image` text COLLATE utf8mb4_unicode_520_ci,
  `quiz_category_id` int(11) unsigned NOT NULL,
  `question_ids` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `ordering` int(16) NOT NULL,
  `published` tinyint(3) unsigned NOT NULL,
  `options` text COLLATE utf8mb4_unicode_520_ci,
  `intervals` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_aysquiz_quizes`
-- Number of rows: 1
--
INSERT INTO `1608867401_aysquiz_quizes` VALUES 
(3,'General Knowledge','General Knowledge quizz free for demo','https://bestseries.in/wp-content/uploads/2020/09/slide_5.jpg',2,'9,10,8,7,30,29,28,27,26,25,24,23,22,21,20',1,1,'{\"color\":\"#27AE60\",\"bg_color\":\"#fff\",\"text_color\":\"#000\",\"height\":350,\"width\":400,\"enable_logged_users\":\"off\",\"information_form\":\"disable\",\"form_name\":null,\"form_email\":null,\"form_phone\":null,\"image_width\":\"\",\"image_height\":\"\",\"enable_correction\":\"off\",\"enable_progress_bar\":\"on\",\"enable_questions_result\":\"off\",\"randomize_questions\":\"on\",\"randomize_answers\":\"on\",\"enable_questions_counter\":\"on\",\"enable_restriction_pass\":\"off\",\"restriction_pass_message\":\"\",\"user_role\":[],\"custom_css\":\"\",\"limit_users\":\"off\",\"limitation_message\":\"\",\"redirect_url\":\"\",\"redirection_delay\":0,\"answers_view\":\"list\",\"enable_rtl_direction\":\"off\",\"enable_logged_users_message\":\"\",\"questions_count\":\"\",\"enable_question_bank\":\"off\",\"enable_live_progress_bar\":\"off\",\"enable_percent_view\":\"off\",\"enable_average_statistical\":\"off\",\"enable_next_button\":\"on\",\"enable_previous_button\":\"on\",\"enable_arrows\":\"off\",\"timer_text\":\"\",\"quiz_theme\":\"classic_light\",\"enable_social_buttons\":\"on\",\"result_text\":\"\",\"enable_pass_count\":\"off\",\"hide_score\":\"off\",\"rate_form_title\":\"\",\"box_shadow_color\":\"#000\",\"quiz_border_radius\":\"0\",\"quiz_bg_image\":\"\",\"quiz_border_width\":\"1\",\"quiz_border_style\":\"solid\",\"quiz_border_color\":\"#000\",\"quiz_loader\":\"hourglass\",\"create_date\":\"2020-09-06 02:10:01\",\"author\":{\"id\":1,\"name\":\"bestseries\"},\"quest_animation\":\"shake\",\"form_title\":\"\",\"enable_bg_music\":\"off\",\"quiz_bg_music\":\"\",\"answers_font_size\":\"15\",\"show_create_date\":\"on\",\"show_author\":\"on\",\"enable_early_finish\":\"off\",\"answers_rw_texts\":\"on_passing\",\"disable_store_data\":\"off\",\"enable_background_gradient\":\"off\",\"background_gradient_color_1\":\"#000\",\"background_gradient_color_2\":\"#fff\",\"quiz_gradient_direction\":\"vertical\",\"redirect_after_submit\":\"off\",\"submit_redirect_url\":\"\",\"submit_redirect_delay\":\"\",\"progress_bar_style\":\"fourth\",\"enable_exit_button\":\"off\",\"exit_redirect_url\":\"\",\"image_sizing\":\"cover\",\"quiz_bg_image_position\":\"center center\",\"custom_class\":\"\",\"enable_social_links\":\"off\",\"social_links\":{\"linkedin_link\":\"\",\"facebook_link\":\"\",\"twitter_link\":\"\"},\"show_quiz_title\":\"on\",\"show_quiz_desc\":\"on\",\"show_login_form\":\"off\",\"mobile_max_width\":\"\",\"limit_users_by\":\"ip\",\"active_date_check\":\"off\",\"activeInterval\":\"2020-12-12 07:02:00\",\"deactiveInterval\":\"2020-12-12 07:02:00\",\"active_date_pre_start_message\":\"The quiz will be available soon!\",\"active_date_message\":\"The quiz has expired!\",\"explanation_time\":\"4\",\"enable_clear_answer\":\"off\",\"show_category\":\"off\",\"show_question_category\":\"off\",\"display_score\":\"by_correctness\",\"enable_rw_asnwers_sounds\":\"off\",\"ans_right_wrong_icon\":\"default\",\"quiz_bg_img_in_finish_page\":\"off\",\"finish_after_wrong_answer\":\"off\",\"after_timer_text\":\"\",\"enable_enter_key\":\"on\",\"buttons_text_color\":\"#000000\",\"buttons_position\":\"center\",\"show_questions_explanation\":\"on_results_page\",\"enable_audio_autoplay\":\"off\",\"buttons_size\":\"medium\",\"buttons_font_size\":\"17\",\"buttons_left_right_padding\":\"20\",\"buttons_top_bottom_padding\":\"10\",\"buttons_border_radius\":\"3\",\"enable_leave_page\":\"on\",\"enable_tackers_count\":\"off\",\"tackers_count\":\"\",\"pass_score\":78,\"pass_score_message\":\"<h4 style=\\\"text-align: center;\\\">Congratulations!<\\/h4>\\r\\n<p style=\\\"text-align: center;\\\">You passed the quiz and won a promo code!<\\/p>\\r\\n\\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 RXMBPRZ10\",\"fail_score_message\":\"<h4 style=\\\"text-align: center;\\\">Congratulations!<\\/h4>\\r\\n<p style=\\\"text-align: center;\\\">You have won a promo code!<\\/p>\\r\\n\\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 \\u00a0 RXMBPRY5\",\"question_font_size\":16,\"quiz_width_by_percentage_px\":\"pixels\",\"questions_hint_icon_or_text\":\"default\",\"questions_hint_value\":\"\",\"required_fields\":null,\"enable_timer\":\"off\",\"enable_quiz_rate\":\"off\",\"enable_rate_avg\":\"off\",\"enable_box_shadow\":\"on\",\"enable_border\":\"off\",\"quiz_timer_in_title\":\"off\",\"enable_rate_comments\":\"off\",\"enable_restart_button\":\"on\",\"autofill_user_data\":\"off\",\"timer\":100}',NULL);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
