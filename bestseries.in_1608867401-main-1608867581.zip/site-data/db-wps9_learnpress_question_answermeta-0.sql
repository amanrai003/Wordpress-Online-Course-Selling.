-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:39
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_learnpress_question_answermeta
-- Snapshot Table  : 1608867401_learnpress_question_answermeta
--
-- SQL    : SELECT * FROM wps9_learnpress_question_answermeta LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_learnpress_question_answermeta`
--
DROP TABLE  IF EXISTS `1608867401_learnpress_question_answermeta`;
CREATE TABLE `1608867401_learnpress_question_answermeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `learnpress_question_answer_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(45) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `meta_value` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_learnpress_question_answermeta`
-- Number of rows: 0
--
--
-- Data for table `wps9_learnpress_question_answermeta`
-- Number of rows: 0
--
SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
