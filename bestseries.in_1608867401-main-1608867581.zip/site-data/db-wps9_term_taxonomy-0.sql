-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_term_taxonomy
-- Snapshot Table  : 1608867401_term_taxonomy
--
-- SQL    : SELECT * FROM wps9_term_taxonomy LIMIT 0,10000
-- Offset : 0
-- Rows   : 31
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_term_taxonomy`
--
DROP TABLE  IF EXISTS `1608867401_term_taxonomy`;
CREATE TABLE `1608867401_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_term_taxonomy`
-- Number of rows: 31
--
INSERT INTO `1608867401_term_taxonomy` VALUES 
(1,1,'category','',0,1),
 (2,2,'nav_menu','',0,7),
 (3,3,'product_type','',0,28),
 (4,4,'product_type','',0,0),
 (5,5,'product_type','',0,0),
 (6,6,'product_type','',0,0),
 (7,7,'product_visibility','',0,0),
 (8,8,'product_visibility','',0,0),
 (9,9,'product_visibility','',0,0),
 (10,10,'product_visibility','',0,0),
 (11,11,'product_visibility','',0,0),
 (12,12,'product_visibility','',0,0),
 (13,13,'product_visibility','',0,0),
 (14,14,'product_visibility','',0,0),
 (15,15,'product_visibility','',0,0),
 (16,16,'product_cat','',0,0),
 (17,17,'course-category','',0,0),
 (18,18,'course-tag','',0,28),
 (19,19,'course-tag','',0,28),
 (20,20,'course-category','',0,8),
 (21,21,'course-category','',0,0),
 (22,22,'course-category','',0,0),
 (23,23,'course-category','',0,0),
 (24,24,'course-category','',0,8),
 (25,25,'course-category','',0,12),
 (29,29,'product_cat','',0,8),
 (26,26,'product_tag','',0,28),
 (27,27,'product_tag','',0,28),
 (28,28,'product_cat','',0,0),
 (30,30,'product_cat','',0,0),
 (31,31,'product_cat','',0,20);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
