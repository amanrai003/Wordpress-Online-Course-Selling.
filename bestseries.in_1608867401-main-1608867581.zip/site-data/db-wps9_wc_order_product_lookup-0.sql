-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_wc_order_product_lookup
-- Snapshot Table  : 1608867401_wc_order_product_lookup
--
-- SQL    : SELECT * FROM wps9_wc_order_product_lookup LIMIT 0,10000
-- Offset : 0
-- Rows   : 14
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_wc_order_product_lookup`
--
DROP TABLE  IF EXISTS `1608867401_wc_order_product_lookup`;
CREATE TABLE `1608867401_wc_order_product_lookup` (
  `order_item_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variation_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT '0',
  `product_gross_revenue` double NOT NULL DEFAULT '0',
  `coupon_amount` double NOT NULL DEFAULT '0',
  `tax_amount` double NOT NULL DEFAULT '0',
  `shipping_amount` double NOT NULL DEFAULT '0',
  `shipping_tax_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `date_created` (`date_created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_wc_order_product_lookup`
-- Number of rows: 14
--
INSERT INTO `1608867401_wc_order_product_lookup` VALUES 
(1,2018,1867,0,1,'2020-10-15 19:26:51',1,100,100,0,0,0,0),
 (2,2020,1869,0,2,'2020-10-17 07:26:42',1,100,100,0,0,0,0),
 (3,2031,1897,0,3,'2020-10-29 14:35:29',1,100,100,0,0,0,0),
 (4,2033,1889,0,4,'2020-10-29 14:37:25',1,100,100,0,0,0,0),
 (5,2035,1889,0,4,'2020-10-30 03:28:51',2,4,4,0,0,0,0),
 (6,2037,1889,0,5,'2020-11-01 03:51:26',1,2,2,0,0,0,0),
 (7,2039,1889,0,6,'2020-11-05 16:04:35',1,2,2,0,0,0,0),
 (8,2073,1889,0,1,'2020-11-09 06:42:52',1,2,2,0,0,0,0),
 (9,2075,1889,0,1,'2020-11-09 19:44:26',1,2,2,0,0,0,0),
 (10,2079,1889,0,6,'2020-11-10 06:14:40',1,2,2,0,0,0,0),
 (11,2081,1889,0,7,'2020-11-10 10:58:43',1,2,2,0,0,0,0),
 (12,2083,1889,0,6,'2020-11-13 10:40:06',2,4,4,0,0,0,0),
 (13,3329,1867,0,6,'2020-12-12 10:08:18',1,159,159,0,0,0,0),
 (14,3347,1883,0,8,'2020-12-20 15:18:42',2,236.6,236.6,101.4,0,0,0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
