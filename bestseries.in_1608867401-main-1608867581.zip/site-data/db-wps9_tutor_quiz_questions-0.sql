-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:39
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_tutor_quiz_questions
-- Snapshot Table  : 1608867401_tutor_quiz_questions
--
-- SQL    : SELECT * FROM wps9_tutor_quiz_questions LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_tutor_quiz_questions`
--
DROP TABLE  IF EXISTS `1608867401_tutor_quiz_questions`;
CREATE TABLE `1608867401_tutor_quiz_questions` (
  `question_id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_id` int(11) DEFAULT NULL,
  `question_title` text COLLATE utf8mb4_unicode_520_ci,
  `question_description` longtext COLLATE utf8mb4_unicode_520_ci,
  `question_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `question_mark` decimal(9,2) DEFAULT NULL,
  `question_settings` longtext COLLATE utf8mb4_unicode_520_ci,
  `question_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_tutor_quiz_questions`
-- Number of rows: 0
--
--
-- Data for table `wps9_tutor_quiz_questions`
-- Number of rows: 0
--
SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
