-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_aysquiz_answers
-- Snapshot Table  : 1608867401_aysquiz_answers
--
-- SQL    : SELECT * FROM wps9_aysquiz_answers LIMIT 0,10000
-- Offset : 0
-- Rows   : 100
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_aysquiz_answers`
--
DROP TABLE  IF EXISTS `1608867401_aysquiz_answers`;
CREATE TABLE `1608867401_aysquiz_answers` (
  `id` int(150) unsigned NOT NULL AUTO_INCREMENT,
  `question_id` int(11) unsigned NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_520_ci,
  `correct` tinyint(1) NOT NULL,
  `ordering` int(11) NOT NULL,
  `weight` double DEFAULT '0',
  `placeholder` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_aysquiz_answers`
-- Number of rows: 100
--
INSERT INTO `1608867401_aysquiz_answers` VALUES 
(24,7,'Chanda Kochar',NULL,0,1,0,''),
 (23,7,'Shikha Sharma',NULL,0,2,0,''),
 (22,7,'Arundhati Bhattacharya',NULL,1,3,0,''),
 (27,8,'Kolkata',NULL,1,2,0,''),
 (26,8,'Dispur',NULL,0,1,0,''),
 (25,7,'Usha Ananthasubramanyan',NULL,0,4,0,''),
 (30,9,'June 21',NULL,1,1,0,''),
 (29,8,'New Delhi',NULL,0,4,0,''),
 (28,8,'Mumbai',NULL,0,3,0,''),
 (32,9,'April 22',NULL,0,3,0,''),
 (31,9,'March 21',NULL,0,2,0,''),
 (33,9,'May 31',NULL,0,4,0,''),
 (34,10,'Girl Education',NULL,0,1,0,''),
 (35,10,'Water Conservation',NULL,1,2,0,''),
 (36,10,'Women Empowerment',NULL,0,3,0,''),
 (37,10,'None of the above',NULL,0,4,0,''),
 (38,11,'September 12',NULL,0,1,0,''),
 (39,11,'September 25',NULL,0,2,0,''),
 (40,11,'September 27',NULL,1,3,0,''),
 (41,11,'September 29',NULL,0,4,0,''),
 (42,12,'Ministry of Development of North Eastern Region (DoNER)',NULL,1,1,0,''),
 (43,12,'Ministry of External Affairs',NULL,0,2,0,''),
 (44,12,'Ministry of Home Affairs',NULL,0,3,0,''),
 (45,12,'Ministry of Defence',NULL,0,4,0,''),
 (46,13,'June 5',NULL,0,1,0,''),
 (47,13,'8th March, every year, International Women\\\'s Day',NULL,1,2,0,''),
 (48,13,'June 21',NULL,0,3,0,''),
 (49,13,'April 7',NULL,0,4,0,''),
 (50,14,'Voter Slip',NULL,0,1,0,''),
 (51,14,'Electoral Photo Identity Cards (EPIC)',NULL,1,2,0,''),
 (52,14,'Indelible ink mark',NULL,0,3,0,''),
 (53,14,'Electoral rolls',NULL,0,4,0,''),
 (54,15,'Bairaj Khanna',NULL,1,1,0,''),
 (55,15,'Ursula Vernon',NULL,0,2,0,''),
 (56,15,'Amal EI-Mohtar',NULL,0,3,0,''),
 (57,15,'Diksha Basu',NULL,0,4,0,''),
 (58,16,'Saffron, White with 24-spoke Wheel, Green',NULL,1,1,0,''),
 (59,16,'Green, White with 24-spoke Wheel, Saffron',NULL,0,2,0,''),
 (60,16,'Saffron, White with 22-spoke Wheel, Green',NULL,0,3,0,''),
 (61,16,'Green, White with 22-spoke Wheel, Saffron',NULL,0,4,0,''),
 (62,17,'Statutory Body',NULL,1,1,0,''),
 (63,17,'Constitutional Body',NULL,0,2,0,''),
 (64,17,'Non Governmental Organization',NULL,0,3,0,''),
 (65,17,'Advisory Body',NULL,0,4,0,''),
 (66,18,'producing hydroelectric power',NULL,1,1,0,''),
 (67,18,'dissolving industrial wastes',NULL,0,2,0,''),
 (68,18,'agricultural irrigation',NULL,0,3,0,''),
 (69,18,'domestic use',NULL,0,4,0,''),
 (70,19,'1 and 2',NULL,0,1,0,''),
 (71,19,'2 and 3',NULL,0,2,0,''),
 (72,19,'3 only',NULL,0,3,0,''),
 (73,19,'1,2 and 3',NULL,1,4,0,''),
 (74,20,'Albert Einstein',NULL,0,1,0,''),
 (75,20,'H. G. Khorana',NULL,0,2,0,''),
 (76,20,'Linus Pauling',NULL,1,3,0,''),
 (77,20,'Paul Berg',NULL,0,4,0,''),
 (78,21,'Meghalaya',NULL,0,1,0,''),
 (79,21,'Sikkim',NULL,1,2,0,''),
 (80,21,'Manipur',NULL,0,3,0,''),
 (81,21,'Kerala',NULL,0,4,0,''),
 (82,22,'Kolkata',NULL,0,1,0,''),
 (83,22,'Mumbai',NULL,0,2,0,''),
 (84,22,'New Delhi',NULL,0,3,0,''),
 (85,22,'Chandigarh',NULL,1,4,0,''),
 (86,23,'Punjab',NULL,0,1,0,''),
 (87,23,'Haryana',NULL,1,2,0,''),
 (88,23,'Uttar Pradesh',NULL,0,3,0,''),
 (89,23,'Madhya Pradesh',NULL,0,4,0,''),
 (90,24,'Shanti Ghat',NULL,0,1,0,''),
 (91,24,'Shakti Sthal',NULL,1,2,0,''),
 (92,24,'Shanti Van',NULL,0,3,0,''),
 (93,24,'Shanti Sthal',NULL,0,4,0,''),
 (94,25,'Jhabua',NULL,0,1,0,''),
 (95,25,'Dindori',NULL,0,2,0,''),
 (96,25,'Mandla',NULL,0,3,0,''),
 (97,25,'Balaghat',NULL,1,4,0,''),
 (98,26,'68.20',NULL,0,1,0,''),
 (99,26,'44.94',NULL,0,2,0,''),
 (100,26,'78.20',NULL,0,3,0,''),
 (101,26,'33',NULL,1,4,0,''),
 (102,27,'1st November, 1959',NULL,0,1,0,''),
 (103,27,'1st September, 1956',NULL,0,2,0,''),
 (104,27,'1st November, 1956',NULL,1,3,0,''),
 (105,27,'1st September, 1951',NULL,0,4,0,''),
 (106,28,'Japan',NULL,0,1,0,''),
 (107,28,'China',NULL,0,2,0,''),
 (108,28,'Australia',NULL,1,3,0,''),
 (109,28,'Egypt',NULL,0,4,0,''),
 (110,29,'Nigeria',NULL,0,1,0,''),
 (111,29,'Mali',NULL,0,2,0,''),
 (112,29,'Liberia',NULL,1,3,0,''),
 (113,29,'Senegal',NULL,0,4,0,''),
 (114,30,'Independence Day',NULL,0,1,0,''),
 (115,30,'Republic Day',NULL,0,2,0,''),
 (116,30,'Gandhi Jayanti',NULL,1,3,0,''),
 (117,30,'Environment Day',NULL,0,4,0,''),
 (118,31,'Air pollution',NULL,0,1,0,''),
 (119,31,'Green House gases',NULL,0,2,0,''),
 (120,31,'Climate change',NULL,1,3,0,''),
 (121,31,'Water pollution',NULL,0,4,0,'');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
