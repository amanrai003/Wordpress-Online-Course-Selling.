-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_terms
-- Snapshot Table  : 1608867401_terms
--
-- SQL    : SELECT * FROM wps9_terms LIMIT 0,10000
-- Offset : 0
-- Rows   : 31
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_terms`
--
DROP TABLE  IF EXISTS `1608867401_terms`;
CREATE TABLE `1608867401_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_terms`
-- Number of rows: 31
--
INSERT INTO `1608867401_terms` VALUES 
(1,'Uncategorized','uncategorized',0),
 (2,'menu','menu',0),
 (3,'simple','simple',0),
 (4,'grouped','grouped',0),
 (5,'variable','variable',0),
 (6,'external','external',0),
 (7,'exclude-from-search','exclude-from-search',0),
 (8,'exclude-from-catalog','exclude-from-catalog',0),
 (9,'featured','featured',0),
 (10,'outofstock','outofstock',0),
 (11,'rated-1','rated-1',0),
 (12,'rated-2','rated-2',0),
 (13,'rated-3','rated-3',0),
 (14,'rated-4','rated-4',0),
 (15,'rated-5','rated-5',0),
 (16,'Uncategorized','uncategorized',0),
 (17,'Test Seies','test-seies',0),
 (18,'Online Test Series','online-test-series',0),
 (19,'Smart Study','smart-study',0),
 (20,'10th','10th',0),
 (21,'9th','9th',0),
 (22,'11th commerce','11th-commerce',0),
 (23,'11th science','11th-science',0),
 (24,'12th commerce','12th-commerce',0),
 (25,'12th science','12th-science',0),
 (26,'Smart study','smart-study',0),
 (27,'Online test series','online-test-series',0),
 (28,'9th class','9th-class',0),
 (29,'10th class','10th-class',0),
 (30,'11th class','11th-class',0),
 (31,'12th class','12th-class',0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
