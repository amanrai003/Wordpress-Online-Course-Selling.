-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_comments
-- Snapshot Table  : 1608867401_comments
--
-- SQL    : SELECT * FROM wps9_comments LIMIT 0,10000
-- Offset : 0
-- Rows   : 36
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_comments`
--
DROP TABLE  IF EXISTS `1608867401_comments`;
CREATE TABLE `1608867401_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `comment_date_gmt` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_comments`
-- Number of rows: 36
--
INSERT INTO `1608867401_comments` VALUES 
(2,2018,'WooCommerce','woocommerce@bestseries.in','','','2020-10-15 19:26:58','2020-10-15 19:26:58','Razorpay OrderId: order_FpIAIl0mZNvAhh',0,'1','WooCommerce','order_note',0,0),
 (3,2018,'WooCommerce','woocommerce@bestseries.in','','','2020-10-15 21:36:00','2020-10-15 21:36:00','Unpaid order cancelled - time limit reached. Order status changed from Pending payment to Cancelled.',0,'1','WooCommerce','order_note',0,0),
 (4,2020,'WooCommerce','woocommerce@bestseries.in','','','2020-10-17 07:26:47','2020-10-17 07:26:47','Razorpay OrderId: order_Fpsxn269vNNDYy',0,'1','WooCommerce','order_note',0,0),
 (5,2020,'WooCommerce','woocommerce@bestseries.in','','','2020-10-17 08:39:42','2020-10-17 08:39:42','Unpaid order cancelled - time limit reached. Order status changed from Pending payment to Cancelled.',0,'1','WooCommerce','order_note',0,0),
 (6,2031,'WooCommerce','woocommerce@bestseries.in','','','2020-10-29 14:35:32','2020-10-29 14:35:32','Razorpay OrderId: order_Fukg8U7y1WlDUG',0,'1','WooCommerce','order_note',0,0),
 (7,2033,'WooCommerce','woocommerce@bestseries.in','','','2020-10-29 14:37:27','2020-10-29 14:37:27','Razorpay OrderId: order_FukiABli2kcSvs',0,'1','WooCommerce','order_note',0,0),
 (8,2031,'WooCommerce','woocommerce@bestseries.in','','','2020-10-29 16:49:33','2020-10-29 16:49:33','Unpaid order cancelled - time limit reached. Order status changed from Pending payment to Cancelled.',0,'1','WooCommerce','order_note',0,0),
 (9,2033,'WooCommerce','woocommerce@bestseries.in','','','2020-10-29 16:49:33','2020-10-29 16:49:33','Unpaid order cancelled - time limit reached. Order status changed from Pending payment to Cancelled.',0,'1','WooCommerce','order_note',0,0),
 (10,2035,'WooCommerce','woocommerce@bestseries.in','','','2020-10-30 03:28:53','2020-10-30 03:28:53','Razorpay OrderId: order_Fuxr3iDIJtdiWs',0,'1','WooCommerce','order_note',0,0),
 (11,2035,'WooCommerce','woocommerce@bestseries.in','','','2020-10-30 05:53:02','2020-10-30 05:53:02','Unpaid order cancelled - time limit reached. Order status changed from Pending payment to Cancelled.',0,'1','WooCommerce','order_note',0,0),
 (12,2037,'WooCommerce','woocommerce@bestseries.in','','','2020-11-01 03:51:29','2020-11-01 03:51:29','Razorpay OrderId: order_FvlJAXXhQ70HJ6',0,'1','WooCommerce','order_note',0,0),
 (13,2037,'WooCommerce','woocommerce@bestseries.in','','','2020-11-01 03:51:56','2020-11-01 03:51:56','Razorpay OrderId: order_FvlJeJvk2KtlyH',0,'1','WooCommerce','order_note',0,0),
 (14,2037,'WooCommerce','woocommerce@bestseries.in','','','2020-11-01 03:52:57','2020-11-01 03:52:57','Order status changed from Pending payment to Processing.',0,'1','WooCommerce','order_note',0,0),
 (15,2037,'WooCommerce','woocommerce@bestseries.in','','','2020-11-01 03:53:00','2020-11-01 03:53:00','Razorpay payment successful <br/>Razorpay Id: pay_FvlKBpu10z0erx',0,'1','WooCommerce','order_note',0,0),
 (16,2037,'bestseries','support@bestseries.in','','','2020-11-01 04:09:37','2020-11-01 04:09:37','Order status changed from Processing to Completed.',0,'1','WooCommerce','order_note',0,0),
 (17,2039,'WooCommerce','woocommerce@bestseries.in','','','2020-11-05 16:04:41','2020-11-05 16:04:41','Razorpay OrderId: order_FxXw9hduHgNLOP',0,'1','WooCommerce','order_note',0,0),
 (18,2039,'WooCommerce','woocommerce@bestseries.in','','','2020-11-05 17:11:26','2020-11-05 17:11:26','Unpaid order cancelled - time limit reached. Order status changed from Pending payment to Cancelled.',0,'1','WooCommerce','order_note',0,0),
 (19,2039,'bestseries','support@bestseries.in','','','2020-11-09 02:49:24','2020-11-09 02:49:24','Order status changed from Cancelled to Completed.',0,'1','WooCommerce','order_note',0,0),
 (20,2073,'WooCommerce','woocommerce@bestseries.in','','','2020-11-09 06:42:55','2020-11-09 06:42:55','Razorpay OrderId: order_FyyVEffW5WSFDD',0,'1','WooCommerce','order_note',0,0),
 (21,2073,'WooCommerce','woocommerce@bestseries.in','','','2020-11-09 08:54:53','2020-11-09 08:54:53','Unpaid order cancelled - time limit reached. Order status changed from Pending payment to Cancelled.',0,'1','WooCommerce','order_note',0,0),
 (22,2075,'WooCommerce','woocommerce@bestseries.in','','','2020-11-09 19:44:33','2020-11-09 19:44:33','Razorpay OrderId: order_FzBot21sZS4Hv3',0,'1','WooCommerce','order_note',0,0),
 (23,2075,'WooCommerce','woocommerce@bestseries.in','','','2020-11-09 19:45:15','2020-11-09 19:45:15','Order status changed from Pending payment to Completed.',0,'1','WooCommerce','order_note',0,0),
 (24,2075,'WooCommerce','woocommerce@bestseries.in','','','2020-11-09 19:45:17','2020-11-09 19:45:17','Razorpay payment successful <br/>Razorpay Id: pay_FzBp7i9rwYmp4E',0,'1','WooCommerce','order_note',0,0),
 (25,2079,'WooCommerce','woocommerce@bestseries.in','','','2020-11-10 06:14:43','2020-11-10 06:14:43','Razorpay OrderId: order_FzMYYxI0JBHuKS',0,'1','WooCommerce','order_note',0,0),
 (26,2079,'WooCommerce','woocommerce@bestseries.in','','','2020-11-10 08:35:55','2020-11-10 08:35:55','Unpaid order cancelled - time limit reached. Order status changed from Pending payment to Cancelled.',0,'1','WooCommerce','order_note',0,0),
 (27,2081,'WooCommerce','woocommerce@bestseries.in','','','2020-11-10 10:58:46','2020-11-10 10:58:46','Razorpay OrderId: order_FzROblg0qhGdD5',0,'1','WooCommerce','order_note',0,0),
 (28,2081,'WooCommerce','woocommerce@bestseries.in','','','2020-11-10 12:24:46','2020-11-10 12:24:46','Unpaid order cancelled - time limit reached. Order status changed from Pending payment to Cancelled.',0,'1','WooCommerce','order_note',0,0),
 (29,2083,'WooCommerce','woocommerce@bestseries.in','','','2020-11-13 10:40:08','2020-11-13 10:40:08','Razorpay OrderId: order_G0cgIOMYBe44Xb',0,'1','WooCommerce','order_note',0,0),
 (30,2083,'WooCommerce','woocommerce@bestseries.in','','','2020-11-13 14:18:16','2020-11-13 14:18:16','Unpaid order cancelled - time limit reached. Order status changed from Pending payment to Cancelled.',0,'1','WooCommerce','order_note',0,0),
 (31,966,'1','','','','2020-11-24 03:29:00','2020-11-24 03:29:00','70ac6a9afdb38fae',0,'approved','TutorLMSPlugin','course_completed',0,1),
 (32,1660,'raj','','','','2020-12-10 11:59:20','2020-12-10 11:59:20','<p style=\"text-align: left\">Hey</p>',0,'waiting_for_answer','TutorLMSPlugin','tutor_q_and_a',0,3),
 (33,339,'3','','','','2020-12-11 09:55:31','2020-12-11 09:55:31','5e3ef63ad6ab6460',0,'approved','TutorLMSPlugin','course_completed',0,3),
 (34,3329,'WooCommerce','woocommerce@bestseries.in','','','2020-12-12 10:08:19','2020-12-12 10:08:19','Razorpay OrderId: order_GC5dBLxxuHKeas',0,'1','WooCommerce','order_note',0,0),
 (35,3329,'bestseries','support@bestseries.in','','','2020-12-16 11:16:48','2020-12-16 11:16:48','Order status changed from Pending payment to Completed.',0,'1','WooCommerce','order_note',0,0),
 (36,3347,'WooCommerce','woocommerce@bestseries.in','','','2020-12-20 15:18:45','2020-12-20 15:18:45','Razorpay OrderId: order_GFLC3IJ2sSnKy5',0,'1','WooCommerce','order_note',0,0),
 (37,3347,'bestseries','support@bestseries.in','','','2020-12-22 08:02:59','2020-12-22 08:02:59','Order status changed from Pending payment to Completed.',0,'1','WooCommerce','order_note',0,0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
