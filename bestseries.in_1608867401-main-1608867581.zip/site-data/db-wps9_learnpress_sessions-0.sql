-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_learnpress_sessions
-- Snapshot Table  : 1608867401_learnpress_sessions
--
-- SQL    : SELECT * FROM wps9_learnpress_sessions LIMIT 0,10000
-- Offset : 0
-- Rows   : 7
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_learnpress_sessions`
--
DROP TABLE  IF EXISTS `1608867401_learnpress_sessions`;
CREATE TABLE `1608867401_learnpress_sessions` (
  `session_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) NOT NULL,
  PRIMARY KEY (`session_key`),
  UNIQUE KEY `session_id` (`session_id`)
) ENGINE=MyISAM AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_learnpress_sessions`
-- Number of rows: 7
--
INSERT INTO `1608867401_learnpress_sessions` VALUES 
(144,'931085919f20f68b2e9f09ee7f9c64f3','a:2:{s:13:\"guest_user_id\";i:1601312221;s:4:\"cart\";s:6:\"a:0:{}\";}',1601485018),
 (143,'d656b4c38dbfcb26ed1dea382089481a','a:3:{s:13:\"guest_user_id\";i:1601288367;s:4:\"cart\";s:6:\"a:0:{}\";s:19:\"user_just_logged_in\";s:3:\"yes\";}',1601633757),
 (145,'6db99dffae681dbb2edf49af3f4c2411','a:2:{s:13:\"guest_user_id\";i:1601349800;s:4:\"cart\";s:6:\"a:0:{}\";}',1601522596),
 (146,'3ad1db265523e0995bd0e61e66cd07c9','a:2:{s:13:\"guest_user_id\";i:1601353476;s:4:\"cart\";s:6:\"a:0:{}\";}',1601526273),
 (147,'339c83ad752ce704340abe15cbfec017','a:2:{s:13:\"guest_user_id\";i:1601452724;s:4:\"cart\";s:6:\"a:0:{}\";}',1601625523),
 (148,'92630b780ea58e045f9746166a4ae0a7','a:2:{s:13:\"guest_user_id\";i:1601456321;s:4:\"cart\";s:6:\"a:0:{}\";}',1601629065),
 (149,'192592c5e7078cb32d607161df85ba99','a:2:{s:13:\"guest_user_id\";i:1601457433;s:4:\"cart\";s:6:\"a:0:{}\";}',1601630227);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
