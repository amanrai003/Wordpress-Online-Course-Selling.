-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_wc_admin_notes
-- Snapshot Table  : 1608867401_wc_admin_notes
--
-- SQL    : SELECT * FROM wps9_wc_admin_notes LIMIT 0,10000
-- Offset : 0
-- Rows   : 13
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_wc_admin_notes`
--
DROP TABLE  IF EXISTS `1608867401_wc_admin_notes`;
CREATE TABLE `1608867401_wc_admin_notes` (
  `note_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `locale` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content_data` longtext COLLATE utf8mb4_unicode_520_ci,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT '0',
  `layout` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `image` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `icon` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'info',
  PRIMARY KEY (`note_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_wc_admin_notes`
-- Number of rows: 13
--
INSERT INTO `1608867401_wc_admin_notes` VALUES 
(1,'wc-admin-onboarding-email-marketing','info','en_US','Tips, product updates, and inspiration','We\'re here for you - get tips, product updates and inspiration straight to your email box','{}','unactioned','woocommerce-admin','2020-09-21 09:01:45',NULL,0,'plain','',0,'info'),
 (2,'wc-admin-marketing-intro','info','en_US','Connect with your audience','Grow your customer base and increase your sales with marketing tools built for WooCommerce.','{}','unactioned','woocommerce-admin','2020-09-21 09:01:45',NULL,0,'plain','',0,'info'),
 (3,'wc-admin-wc-helper-connection','info','en_US','Connect to WooCommerce.com','Connect to get important product notifications and updates.','{}','unactioned','woocommerce-admin','2020-09-21 09:01:45',NULL,0,'plain','',0,'info'),
 (4,'wc-admin-mobile-app','info','en_US','Install Woo mobile app','Install the WooCommerce mobile app to manage orders, receive sales notifications, and view key metrics — wherever you are.','{}','unactioned','woocommerce-admin','2020-09-23 12:32:42',NULL,0,'plain','',0,'info'),
 (5,'wc-admin-onboarding-payments-reminder','info','en_US','Start accepting payments on your store!','Take payments with the provider that’s right for you - choose from 100+ payment gateways for WooCommerce.','{}','unactioned','woocommerce-admin','2020-09-26 09:26:49',NULL,0,'plain','',0,'info'),
 (6,'wc-admin-usage-tracking-opt-in','info','en_US','Help WooCommerce improve with usage tracking','Gathering usage data allows us to improve WooCommerce. Your store will be considered as we evaluate new features, judge the quality of an update, or determine if an improvement makes sense. You can always visit the <a href=\"https://bestseries.in/wp-admin/admin.php?page=wc-settings&#038;tab=advanced&#038;section=woocommerce_com\" target=\"_blank\">Settings</a> and choose to stop sharing data. <a href=\"https://woocommerce.com/usage-tracking\" target=\"_blank\">Read more</a> about what data we collect.','{}','unactioned','woocommerce-admin','2020-09-28 10:19:26',NULL,0,'plain','',0,'info'),
 (7,'wc-admin-store-notice-giving-feedback-2','info','en_US','Give feedback','Now that you’ve chosen us as a partner, our goal is to make sure we\'re providing the right tools to meet your needs. We\'re looking forward to having your feedback on the store setup experience so we can improve it in the future.','{}','unactioned','woocommerce-admin','2020-09-29 10:42:47',NULL,0,'plain','',0,'info'),
 (8,'wc-admin-insight-first-sale','survey','en_US','Did you know?','A WooCommerce powered store needs on average 31 days to get the first sale. You\'re on the right track! Do you find this type of insight useful?','{}','unactioned','woocommerce-admin','2020-09-29 10:42:47',NULL,0,'plain','',0,'info'),
 (9,'wc-admin-home-screen-feedback','info','en_US','Help us improve the WooCommerce Home screen','We\'d love your input to shape the future of the WooCommerce Home screen together. Feel free to share any feedback, ideas or suggestions that you have.','{}','unactioned','woocommerce-admin','2020-10-03 09:34:29',NULL,0,'plain','',0,'info'),
 (10,'wc-admin-coupon-page-moved','update','en_US','Coupon management has moved!','Coupons can now be managed from Marketing &gt; Coupons. Click the button below to remove the legacy WooCommerce &gt; Coupons menu item.','{}','unactioned','woocommerce-admin','2020-10-10 14:15:50',NULL,0,'plain','',0,'info'),
 (11,'wc-admin-orders-milestone','info','en_US','First order received','Congratulations on getting your first order! Now is a great time to learn how to manage your orders.','{}','unactioned','woocommerce-admin','2020-10-15 21:35:58',NULL,0,'plain','',0,'info'),
 (14,'wc-admin-new-sales-record','info','en_US','New sales record!','Woohoo, December 20th was your record day for sales! Net Sales was ₹236.60 beating the previous record of ₹200.00 set on October 29th.','{\"old_record_date\":\"2020-10-29\",\"old_record_amt\":200,\"new_record_date\":\"2020-12-20\",\"new_record_amt\":236.599999999999994315658113919198513031005859375}','unactioned','woocommerce-admin','2020-12-21 09:02:53',NULL,0,'plain','',0,'info'),
 (13,'wc-admin-real-time-order-alerts','info','en_US','Get real-time order alerts anywhere','Get notifications about store activity, including new orders and product reviews directly on your mobile devices with the Woo app.','{}','unactioned','woocommerce-admin','2020-12-20 09:24:41',NULL,0,'plain','',0,'info');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
