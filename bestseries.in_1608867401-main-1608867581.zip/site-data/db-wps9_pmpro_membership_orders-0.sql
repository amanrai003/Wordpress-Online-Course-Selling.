-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:38
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_pmpro_membership_orders
-- Snapshot Table  : 1608867401_pmpro_membership_orders
--
-- SQL    : SELECT * FROM wps9_pmpro_membership_orders LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_pmpro_membership_orders`
--
DROP TABLE  IF EXISTS `1608867401_pmpro_membership_orders`;
CREATE TABLE `1608867401_pmpro_membership_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_id` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `membership_id` int(11) unsigned NOT NULL DEFAULT '0',
  `paypal_token` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `billing_name` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `billing_street` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `billing_city` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `billing_state` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `billing_zip` varchar(16) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `billing_country` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `billing_phone` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `subtotal` varchar(16) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax` varchar(16) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `couponamount` varchar(16) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `checkout_id` int(11) NOT NULL DEFAULT '0',
  `certificate_id` int(11) NOT NULL DEFAULT '0',
  `certificateamount` varchar(16) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `total` varchar(16) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `payment_type` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `cardtype` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `accountnumber` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `expirationmonth` char(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `expirationyear` varchar(4) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `status` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `gateway` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `gateway_environment` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `payment_transaction_id` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `subscription_transaction_id` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `affiliate_id` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `affiliate_subid` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `session_id` (`session_id`),
  KEY `user_id` (`user_id`),
  KEY `membership_id` (`membership_id`),
  KEY `status` (`status`),
  KEY `timestamp` (`timestamp`),
  KEY `gateway` (`gateway`),
  KEY `gateway_environment` (`gateway_environment`),
  KEY `payment_transaction_id` (`payment_transaction_id`),
  KEY `subscription_transaction_id` (`subscription_transaction_id`),
  KEY `affiliate_id` (`affiliate_id`),
  KEY `affiliate_subid` (`affiliate_subid`),
  KEY `checkout_id` (`checkout_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_pmpro_membership_orders`
-- Number of rows: 0
--
--
-- Data for table `wps9_pmpro_membership_orders`
-- Number of rows: 0
--
SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
