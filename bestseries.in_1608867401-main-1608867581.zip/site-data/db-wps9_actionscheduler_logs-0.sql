-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_actionscheduler_logs
-- Snapshot Table  : 1608867401_actionscheduler_logs
--
-- SQL    : SELECT * FROM wps9_actionscheduler_logs LIMIT 0,10000
-- Offset : 0
-- Rows   : 86
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_actionscheduler_logs`
--
DROP TABLE  IF EXISTS `1608867401_actionscheduler_logs`;
CREATE TABLE `1608867401_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `log_date_local` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=MyISAM AUTO_INCREMENT=452 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_actionscheduler_logs`
-- Number of rows: 86
--
INSERT INTO `1608867401_actionscheduler_logs` VALUES 
(391,236,'action complete via Async Request','2020-12-09 06:23:49','2020-12-09 06:23:49'),
 (388,235,'action complete via Async Request','2020-12-08 09:55:13','2020-12-08 09:55:13'),
 (448,255,'action complete via Async Request','2020-12-23 11:19:45','2020-12-23 11:19:45'),
 (447,255,'action started via Async Request','2020-12-23 11:19:45','2020-12-23 11:19:45'),
 (431,250,'action created','2020-12-22 07:57:21','2020-12-22 07:57:21'),
 (428,248,'action complete via Async Request','2020-12-20 15:21:53','2020-12-20 15:21:53'),
 (429,249,'action started via Async Request','2020-12-20 15:21:53','2020-12-20 15:21:53'),
 (430,249,'action complete via Async Request','2020-12-20 15:21:53','2020-12-20 15:21:53'),
 (400,239,'action complete via Async Request','2020-12-09 18:15:24','2020-12-09 18:15:24'),
 (401,240,'action created','2020-12-10 14:44:47','2020-12-10 14:44:47'),
 (382,233,'action complete via Async Request','2020-12-05 08:28:28','2020-12-05 08:28:28'),
 (383,234,'action created','2020-12-07 04:21:14','2020-12-07 04:21:14'),
 (386,235,'action created','2020-12-08 09:55:12','2020-12-08 09:55:12'),
 (385,234,'action complete via Async Request','2020-12-07 04:21:15','2020-12-07 04:21:15'),
 (381,233,'action started via Async Request','2020-12-05 08:28:28','2020-12-05 08:28:28'),
 (397,238,'action complete via Async Request','2020-12-09 14:44:10','2020-12-09 14:44:10'),
 (384,234,'action started via Async Request','2020-12-07 04:21:15','2020-12-07 04:21:15'),
 (399,239,'action started via Async Request','2020-12-09 18:15:24','2020-12-09 18:15:24'),
 (398,239,'action created','2020-12-09 18:14:05','2020-12-09 18:14:05'),
 (389,236,'action created','2020-12-09 06:22:49','2020-12-09 06:22:49'),
 (392,237,'action created','2020-12-09 14:44:03','2020-12-09 14:44:03'),
 (393,237,'action started via Async Request','2020-12-09 14:44:04','2020-12-09 14:44:04'),
 (394,237,'action complete via Async Request','2020-12-09 14:44:04','2020-12-09 14:44:04'),
 (395,238,'action created','2020-12-09 14:44:04','2020-12-09 14:44:04'),
 (396,238,'action started via Async Request','2020-12-09 14:44:10','2020-12-09 14:44:10'),
 (387,235,'action started via Async Request','2020-12-08 09:55:13','2020-12-08 09:55:13'),
 (390,236,'action started via Async Request','2020-12-09 06:23:49','2020-12-09 06:23:49'),
 (410,243,'action created','2020-12-12 10:08:18','2020-12-12 10:08:18'),
 (411,244,'action created','2020-12-12 10:08:18','2020-12-12 10:08:18'),
 (414,243,'action started via Async Request','2020-12-13 09:04:54','2020-12-13 09:04:54'),
 (406,241,'action complete via Async Request','2020-12-12 00:09:36','2020-12-12 00:09:36'),
 (416,245,'action created','2020-12-16 11:15:00','2020-12-16 11:15:00'),
 (440,252,'action complete via Async Request','2020-12-22 08:03:18','2020-12-22 08:03:18'),
 (413,244,'action complete via Async Request','2020-12-13 09:04:54','2020-12-13 09:04:54'),
 (405,241,'action started via Async Request','2020-12-12 00:09:36','2020-12-12 00:09:36'),
 (412,244,'action started via Async Request','2020-12-13 09:04:54','2020-12-13 09:04:54'),
 (420,246,'action started via Async Request','2020-12-16 11:17:12','2020-12-16 11:17:12'),
 (418,245,'action complete via Async Request','2020-12-16 11:15:01','2020-12-16 11:15:01'),
 (419,246,'action created','2020-12-16 11:16:48','2020-12-16 11:16:48'),
 (417,245,'action started via Async Request','2020-12-16 11:15:01','2020-12-16 11:15:01'),
 (434,251,'action created','2020-12-22 08:02:36','2020-12-22 08:02:36'),
 (346,221,'action created','2020-11-17 03:06:53','2020-11-17 03:06:53'),
 (424,247,'action complete via Async Request','2020-12-18 07:56:07','2020-12-18 07:56:07'),
 (437,251,'action started via Async Request','2020-12-22 08:03:18','2020-12-22 08:03:18'),
 (436,253,'action created','2020-12-22 08:02:59','2020-12-22 08:02:59'),
 (435,252,'action created','2020-12-22 08:02:59','2020-12-22 08:02:59'),
 (379,232,'action complete via Async Request','2020-11-24 03:26:44','2020-11-24 03:26:44'),
 (378,232,'action started via Async Request','2020-11-24 03:26:44','2020-11-24 03:26:44'),
 (377,232,'action created','2020-11-24 03:25:02','2020-11-24 03:25:02'),
 (376,231,'action complete via Async Request','2020-11-24 02:39:30','2020-11-24 02:39:30'),
 (375,231,'action started via Async Request','2020-11-24 02:39:30','2020-11-24 02:39:30'),
 (374,231,'action created','2020-11-24 02:39:27','2020-11-24 02:39:27'),
 (446,255,'action created','2020-12-23 09:02:56','2020-12-23 09:02:56'),
 (444,254,'action started via Async Request','2020-12-23 08:45:37','2020-12-23 08:45:37'),
 (445,254,'action complete via Async Request','2020-12-23 08:45:37','2020-12-23 08:45:37'),
 (427,248,'action started via Async Request','2020-12-20 15:21:52','2020-12-20 15:21:52'),
 (364,227,'action created','2021-01-01 22:43:49','2021-01-01 22:43:49'),
 (363,225,'action complete via WP Cron','2021-01-01 22:43:49','2021-01-01 22:43:49'),
 (361,226,'action created','2021-01-01 22:43:49','2021-01-01 22:43:49'),
 (362,225,'action started via WP Cron','2021-01-01 22:43:49','2021-01-01 22:43:49'),
 (360,221,'action complete via WP Cron','2021-01-01 22:43:49','2021-01-01 22:43:49'),
 (359,221,'action started via WP Cron','2021-01-01 22:43:49','2021-01-01 22:43:49'),
 (404,241,'action created','2020-12-12 00:09:35','2020-12-12 00:09:35'),
 (403,240,'action complete via Async Request','2020-12-10 14:45:24','2020-12-10 14:45:24'),
 (402,240,'action started via Async Request','2020-12-10 14:45:24','2020-12-10 14:45:24'),
 (451,256,'action complete via Async Request','2020-12-24 08:55:51','2020-12-24 08:55:51'),
 (450,256,'action started via Async Request','2020-12-24 08:55:51','2020-12-24 08:55:51'),
 (443,254,'action created','2020-12-23 08:44:44','2020-12-23 08:44:44'),
 (449,256,'action created','2020-12-24 08:55:50','2020-12-24 08:55:50'),
 (442,253,'action complete via Async Request','2020-12-22 08:03:18','2020-12-22 08:03:18'),
 (441,253,'action started via Async Request','2020-12-22 08:03:18','2020-12-22 08:03:18'),
 (415,243,'action complete via Async Request','2020-12-13 09:04:54','2020-12-13 09:04:54'),
 (409,242,'action complete via Async Request','2020-12-12 05:37:51','2020-12-12 05:37:51'),
 (408,242,'action started via Async Request','2020-12-12 05:37:51','2020-12-12 05:37:51'),
 (407,242,'action created','2020-12-12 05:37:35','2020-12-12 05:37:35'),
 (439,252,'action started via Async Request','2020-12-22 08:03:18','2020-12-22 08:03:18'),
 (422,247,'action created','2020-12-18 07:56:06','2020-12-18 07:56:06'),
 (438,251,'action complete via Async Request','2020-12-22 08:03:18','2020-12-22 08:03:18'),
 (421,246,'action complete via Async Request','2020-12-16 11:17:12','2020-12-16 11:17:12'),
 (433,250,'action complete via Async Request','2020-12-22 07:57:23','2020-12-22 07:57:23'),
 (432,250,'action started via Async Request','2020-12-22 07:57:23','2020-12-22 07:57:23'),
 (426,249,'action created','2020-12-20 15:18:42','2020-12-20 15:18:42'),
 (425,248,'action created','2020-12-20 15:18:42','2020-12-20 15:18:42'),
 (423,247,'action started via Async Request','2020-12-18 07:56:07','2020-12-18 07:56:07'),
 (358,225,'action created','2020-11-17 07:30:55','2020-11-17 07:30:55'),
 (380,233,'action created','2020-12-05 08:28:14','2020-12-05 08:28:14');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
