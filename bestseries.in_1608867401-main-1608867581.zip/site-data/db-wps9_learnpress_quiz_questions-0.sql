-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_learnpress_quiz_questions
-- Snapshot Table  : 1608867401_learnpress_quiz_questions
--
-- SQL    : SELECT * FROM wps9_learnpress_quiz_questions LIMIT 0,10000
-- Offset : 0
-- Rows   : 20
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_learnpress_quiz_questions`
--
DROP TABLE  IF EXISTS `1608867401_learnpress_quiz_questions`;
CREATE TABLE `1608867401_learnpress_quiz_questions` (
  `quiz_question_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `quiz_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `question_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `question_order` bigint(20) unsigned NOT NULL DEFAULT '1',
  `params` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`quiz_question_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_learnpress_quiz_questions`
-- Number of rows: 20
--
INSERT INTO `1608867401_learnpress_quiz_questions` VALUES 
(1,37,40,1,NULL),
 (2,37,42,2,NULL),
 (3,37,43,3,NULL),
 (4,37,45,4,NULL),
 (5,37,46,5,NULL),
 (6,49,51,1,NULL),
 (7,49,52,2,NULL),
 (8,49,53,3,NULL),
 (9,49,54,4,NULL),
 (10,49,55,5,NULL),
 (11,56,58,1,NULL),
 (12,56,59,2,NULL),
 (13,56,60,3,NULL),
 (14,56,61,4,NULL),
 (15,56,62,5,NULL),
 (16,66,68,1,NULL),
 (17,66,69,2,NULL),
 (18,66,70,3,NULL),
 (19,66,71,4,NULL),
 (20,66,72,5,NULL);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
