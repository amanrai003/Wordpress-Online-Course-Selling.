-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_wc_admin_note_actions
-- Snapshot Table  : 1608867401_wc_admin_note_actions
--
-- SQL    : SELECT * FROM wps9_wc_admin_note_actions LIMIT 0,10000
-- Offset : 0
-- Rows   : 14
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_wc_admin_note_actions`
--
DROP TABLE  IF EXISTS `1608867401_wc_admin_note_actions`;
CREATE TABLE `1608867401_wc_admin_note_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `note_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `query` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT '0',
  `actioned_text` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`action_id`),
  KEY `note_id` (`note_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_wc_admin_note_actions`
-- Number of rows: 14
--
INSERT INTO `1608867401_wc_admin_note_actions` VALUES 
(1,1,'yes-please','Yes please!','https://woocommerce.us8.list-manage.com/subscribe/post?u=2c1434dc56f9506bf3c3ecd21&amp;id=13860df971&amp;SIGNUPPAGE=plugin','actioned',0,''),
 (2,2,'open-marketing-hub','Open marketing hub','https://bestseries.in/wp-admin/admin.php?page=wc-admin&path=/marketing','actioned',0,''),
 (3,3,'connect','Connect','?page=wc-addons&section=helper','unactioned',0,''),
 (4,4,'learn-more','Learn more','https://woocommerce.com/mobile/','actioned',0,''),
 (5,5,'view-payment-gateways','Learn more','https://woocommerce.com/product-category/woocommerce-extensions/payment-gateways/','actioned',1,''),
 (6,6,'tracking-opt-in','Activate usage tracking','','actioned',1,''),
 (7,7,'share-feedback','Share feedback','https://automattic.survey.fm/new-onboarding-survey','actioned',0,''),
 (8,8,'affirm-insight-first-sale','Yes','','actioned',0,'Thanks for your feedback'),
 (9,8,'deny-insight-first-sale','No','','actioned',0,'Thanks for your feedback'),
 (10,9,'home-screen-feedback-share-feedback','Share feedback','https://automattic.survey.fm/home-screen-survey','actioned',0,''),
 (11,10,'remove-legacy-coupon-menu','Remove legacy coupon menu','https://bestseries.in/wp-admin/admin.php?page=wc-admin&action=remove-coupon-menu','actioned',1,''),
 (12,11,'learn-more','Learn more','https://docs.woocommerce.com/document/managing-orders/?utm_source=inbox','actioned',0,''),
 (15,14,'view-report','View report','?page=wc-admin&path=/analytics/revenue&period=custom&compare=previous_year&after=2020-12-20&before=2020-12-20','actioned',0,''),
 (14,13,'learn-more','Learn more','https://woocommerce.com/mobile/?utm_source=inbox','actioned',0,'');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
