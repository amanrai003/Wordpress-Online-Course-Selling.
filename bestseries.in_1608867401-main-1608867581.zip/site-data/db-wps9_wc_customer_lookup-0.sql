-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_wc_customer_lookup
-- Snapshot Table  : 1608867401_wc_customer_lookup
--
-- SQL    : SELECT * FROM wps9_wc_customer_lookup LIMIT 0,10000
-- Offset : 0
-- Rows   : 8
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_wc_customer_lookup`
--
DROP TABLE  IF EXISTS `1608867401_wc_customer_lookup`;
CREATE TABLE `1608867401_wc_customer_lookup` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `postcode` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_wc_customer_lookup`
-- Number of rows: 8
--
INSERT INTO `1608867401_wc_customer_lookup` VALUES 
(1,NULL,'','Raj','Sonaniya','arjun.100naniya@gmail.com','2020-10-15 19:26:51',NULL,'IN','465333','Arniya kalan','MP'),
 (2,NULL,'','Meghansh','saxena','meghanshsaxena1@gmail.com','2020-10-17 07:26:42',NULL,'IN','465333','arniyua kaalan','MP'),
 (3,NULL,'','Praveen','Sharma','sharmapraveen5749@gmail.com','2020-10-29 14:35:29',NULL,'IN','452001','Indore','MP'),
 (4,NULL,'','Aman','Rai','amanraiy@yahoo.in','2020-10-29 14:37:25',NULL,'IN','451115','Barwaha','MP'),
 (5,1,'bestseries','Develophic-','Co-operates','support@bestseries.in','2020-12-25 00:00:00','2020-09-01 06:30:08','IN','451115','Barwaha','MP'),
 (7,7,'meghanshsaxena','Meghansh','Saxena','meghanshhsaxenaa@gmail.com','2020-12-24 00:00:00','2020-11-10 10:51:05','IN','465333','sjp','BR'),
 (6,3,'raj','Raj','Patel','rajsonaniya24@gmail.com','2020-12-24 00:00:00','2020-10-03 16:43:37','IN','465333','Arniya Kalan','MP'),
 (8,20,'mahirajat','Mahi','Patel','Babita.100naniya@gmail.com','2020-12-20 00:00:00','2020-12-20 15:14:14','IN','465333','Arniyakalan','MP');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
