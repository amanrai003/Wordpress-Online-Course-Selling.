-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_wc_order_stats
-- Snapshot Table  : 1608867401_wc_order_stats
--
-- SQL    : SELECT * FROM wps9_wc_order_stats LIMIT 0,10000
-- Offset : 0
-- Rows   : 14
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_wc_order_stats`
--
DROP TABLE  IF EXISTS `1608867401_wc_order_stats`;
CREATE TABLE `1608867401_wc_order_stats` (
  `order_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `date_created_gmt` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `num_items_sold` int(11) NOT NULL DEFAULT '0',
  `total_sales` double NOT NULL DEFAULT '0',
  `tax_total` double NOT NULL DEFAULT '0',
  `shipping_total` double NOT NULL DEFAULT '0',
  `net_total` double NOT NULL DEFAULT '0',
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `date_created` (`date_created`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_wc_order_stats`
-- Number of rows: 14
--
INSERT INTO `1608867401_wc_order_stats` VALUES 
(2018,0,'2020-10-15 19:26:51','2020-10-15 19:26:51',1,100,0,0,100,0,'wc-cancelled',1),
 (2020,0,'2020-10-17 07:26:42','2020-10-17 07:26:42',1,100,0,0,100,0,'wc-cancelled',2),
 (2031,0,'2020-10-29 14:35:29','2020-10-29 14:35:29',1,100,0,0,100,0,'wc-cancelled',3),
 (2033,0,'2020-10-29 14:37:25','2020-10-29 14:37:25',1,100,0,0,100,0,'wc-cancelled',4),
 (2035,0,'2020-10-30 03:28:51','2020-10-30 03:28:51',2,4,0,0,4,0,'wc-cancelled',4),
 (2037,0,'2020-11-01 03:51:26','2020-11-01 03:51:26',1,2,0,0,2,0,'wc-completed',5),
 (2039,0,'2020-11-05 16:04:35','2020-11-05 16:04:35',1,2,0,0,2,0,'wc-completed',6),
 (2073,0,'2020-11-09 06:42:52','2020-11-09 06:42:52',1,2,0,0,2,0,'wc-cancelled',1),
 (2075,0,'2020-11-09 19:44:26','2020-11-09 19:44:26',1,2,0,0,2,0,'wc-completed',1),
 (2079,0,'2020-11-10 06:14:40','2020-11-10 06:14:40',1,2,0,0,2,1,'wc-cancelled',6),
 (2081,0,'2020-11-10 10:58:43','2020-11-10 10:58:43',1,2,0,0,2,0,'wc-cancelled',7),
 (2083,0,'2020-11-13 10:40:06','2020-11-13 10:40:06',2,4,0,0,4,1,'wc-cancelled',6),
 (3329,0,'2020-12-12 10:08:18','2020-12-12 10:08:18',1,159,0,0,159,1,'wc-completed',6),
 (3347,0,'2020-12-20 15:18:42','2020-12-20 15:18:42',2,236.6,0,0,236.6,0,'wc-completed',8);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
