-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_cli_scripts
-- Snapshot Table  : 1608867401_cli_scripts
--
-- SQL    : SELECT * FROM wps9_cli_scripts LIMIT 0,10000
-- Offset : 0
-- Rows   : 3
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_cli_scripts`
--
DROP TABLE  IF EXISTS `1608867401_cli_scripts`;
CREATE TABLE `1608867401_cli_scripts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliscript_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `cliscript_category` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `cliscript_type` int(11) DEFAULT '0',
  `cliscript_status` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `cliscript_description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `cliscript_key` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_cli_scripts`
-- Number of rows: 3
--
INSERT INTO `1608867401_cli_scripts` VALUES 
(1,'Official Facebook Pixel','-1',1,'yes','Official Facebook Pixel','facebook-for-wordpress',0),
 (2,'Smash Balloon Twitter Feed','-1',1,'yes','Twitter Feed By Smash Baloon','twitter-feed',0),
 (3,'Smash Balloon Instagram Feed','-1',1,'yes','Instagram Feed By Smash Baloon','instagram-feed',0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
