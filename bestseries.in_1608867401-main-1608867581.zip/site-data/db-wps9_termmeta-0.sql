-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/12/25 on 03:37
--
-- Database : bestseri_wp370
--
-- Backup   Table  : wps9_termmeta
-- Snapshot Table  : 1608867401_termmeta
--
-- SQL    : SELECT * FROM wps9_termmeta LIMIT 0,10000
-- Offset : 0
-- Rows   : 11
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1608867401_termmeta`
--
DROP TABLE  IF EXISTS `1608867401_termmeta`;
CREATE TABLE `1608867401_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wps9_termmeta`
-- Number of rows: 11
--
INSERT INTO `1608867401_termmeta` VALUES 
(1,16,'product_count_product_cat','0'),
 (2,26,'product_count_product_tag','28'),
 (3,27,'product_count_product_tag','28'),
 (4,28,'order','0'),
 (5,28,'product_count_product_cat','0'),
 (6,29,'order','0'),
 (7,29,'product_count_product_cat','8'),
 (8,30,'order','0'),
 (9,30,'product_count_product_cat','0'),
 (10,31,'order','0'),
 (11,31,'product_count_product_cat','20');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
