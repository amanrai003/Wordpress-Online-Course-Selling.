<?php include('template-library-live-button.php'); ?>

<a  href="https://go.wpmet.com/ekitpro" target="_blank" >
	<button class="elementor-template-library-template-action elementskit-preview-button-go-pro elementskit-template-library-template-insert elementskit-preview-button-go-pro elementor-button elementor-button-success" >
		<i class="eicon-heart"></i><span class="elementor-button-title"><?php
			esc_html_e( 'Go Pro', 'elementskit-lite' );
		?></span>
	</button>
</a>