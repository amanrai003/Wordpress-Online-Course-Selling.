<button type="button" class="elementskit-template-library-back">
	<i class="dashicons dashicons-arrow-left-alt2"></i>
	<?php esc_html_e( 'Back to Library', 'elementskit-lite' ); ?>
</button>