<?php
defined( 'ABSPATH' ) || exit;

/**
 * XLWCTY Template Name: One Column
 **/
?>
<div class="xlwcty_wrap xlwctyCenter xlwcty_circle_show">
    <div class="xlwcty_in_wrap">
		<?php xlwcty_Core()->public->render(); ?>
    </div>
</div>
